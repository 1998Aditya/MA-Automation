package MA_MSG_Suite_OB;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import io.github.bonigarcia.wdm.WebDriverManager;
import okhttp3.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.*;

import okhttp3.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;


import java.io.*;
import java.time.Duration;
import java.util.*;









public class Main7_MakePickCart {




    public static WebDriver driver;
    public static String cartId;//Load
    public static String locationP = "PT2L100";

    //NEED TO TAKE CARE OF SHEETNAME
    public static void main(String filePath, String testcase, String env) throws IOException, InterruptedException {
//        String filePath = "C:\\Use
//        rs\\2210420\\IdeaProjects\\Testcases\\OOdata.xlsx";
//        String testcase = "TST_002"; // You can pass this dynamically


        Map<String, List<String>> taskGroupToTaskIds = getTaskGroupsForTestcase(filePath, "Tasks", testcase);
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");

        driver = new ChromeDriver(options);
        driver.manage().window().maximize();
        Main1_URL_Login1 login1 = new Main1_URL_Login1(driver, env);
        login1.execute();
        System.out.println("login done:\n");
        SearchMenuWM("WM Mobile","WMMobile");

        for (Map.Entry<String, List<String>> entry : taskGroupToTaskIds.entrySet()) {
            String taskGroupId = entry.getKey();
            List<String> taskIds = entry.getValue();
            System.out.println("Processing Task Group: " + taskGroupId);
            SettingtheTaskGroupfromExcel(taskGroupId);
            int index = 0;
            while (index < taskIds.size()) {
                System.out.println("TaskId Size"+taskIds.size());
                SearchInWmMobile("JD Make Pick Cart", "jdmakepickcart");
                int count = 1;
                cartId = WMEnterDynamicCartID();
                if (Nomoretasksdailogbox()) {
                    System.out.println("Task is in Held Status OR No more tasks dialog detected after MakePickCartandpick.");
                    backWMMobie();
                    break;
                }

                for (int i = 0; i < 6 && index < taskIds.size(); i++) {
                    clickTapToConfirmButton();
                    SlotinputButton(String.format("%02d", count));
                    count++;
                    System.out.println("print count"+count);
                    index++;
                    System.out.println("print index"+index);

                    if (Nomoretasksdailogbox()) {
                        System.out.println("No more tasks dialog detected. Moving to next task group...");
                        // ClickEndcart();
                        Thread.sleep(5000);
                        clickTapToConfirmButton2();
                        Thread.sleep(5000);
                        clickTapToConfirmButton2();
                        Thread.sleep(5000);
                        clickTapToConfirmButton2();
                        Thread.sleep(8000);
                        ScanCartID(cartId);
                        Thread.sleep(3000);

                        while (true) {
                            boolean foundAny = false;

                            if (isElementPresent("acceptlocation_barcodetextfield_location")) {
                                SourceLocation();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            if (isElementPresent("acceptitem_barcodetextfield_item")) {
                                ItemBarcode();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            if (isElementPresent("acceptquantity_naturalquantityfield_need")) {
                                EnterUnit();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            if (isElementPresent("confirmolpntocompletepick_barcodetextfield_olpn")) {
                                EnterOlpn();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            clickOkAlertButton();

                            if (!foundAny) {
                                System.out.println("🚪 No target elements found. Exiting loop.");
                                break;
                            }
                        }



                        Thread.sleep(5000);
                        System.out.println("start ScanCartID2 ");
                        ScanCartID2(cartId);
                        Thread.sleep(3000);
                        Packlocation();
                        Thread.sleep(5000);
                        // Wait until the ion-buttons container is present
                        WmActionBack();
                        Thread.sleep(3000);
                       // WmActionSubmenuBack();
                        Thread.sleep(3000);
                       // WmActionSubmenuBack();


                       // break;
                    }
                    // If dialog was detected, break outer loop too
                    else if ( count == 7 ) {
                        System.out.println("2nd wala ");
                        ClickEndcart();
                        Thread.sleep(5000);
                        clickTapToConfirmButton2();
                        Thread.sleep(5000);
                        clickTapToConfirmButton2();
                        Thread.sleep(5000);
                        clickTapToConfirmButton2();
                        Thread.sleep(8000);
                        ScanCartID(cartId);
                        Thread.sleep(3000);

                        while (true) {
                            boolean foundAny = false;

                            if (isElementPresent("acceptlocation_barcodetextfield_location")) {
                                SourceLocation();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            if (isElementPresent("acceptitem_barcodetextfield_item")) {
                                ItemBarcode();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            if (isElementPresent("acceptquantity_naturalquantityfield_need")) {
                                EnterUnit();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            if (isElementPresent("confirmolpntocompletepick_barcodetextfield_olpn")) {
                                EnterOlpn();
                                Thread.sleep(3000);
                                foundAny = true;
                            }

                            clickOkAlertButton();

                            if (!foundAny) {
                                System.out.println("🚪 No target elements found. Exiting loop.");
                                break;
                            }
                        }


                        Thread.sleep(5000);
                        System.out.println("start ScanCartID2 ");
                        ScanCartID2(cartId);
                        Thread.sleep(3000);
                        Packlocation();
                        Thread.sleep(5000);
                        // Wait until the ion-buttons container is present
                        WmActionBack();
                        Thread.sleep(3000);
                        // WmActionSubmenuBack();
                        Thread.sleep(3000);
                        // WmActionSubmenuBack();

                        // break;
                    }
                }


            }
        }
    }



    public static Map<String, List<String>> getTaskGroupsForTestcase(String filePath, String sheetName, String testcase) throws IOException {
        Map<String, List<String>> taskGroupMap = new LinkedHashMap<>();

        FileInputStream fis = new FileInputStream(filePath);
        Workbook workbook = new XSSFWorkbook(fis);
        Sheet sheet = workbook.getSheet(sheetName);

        for (Row row : sheet) {
            if (row.getRowNum() == 0) continue; // Skip header

            Cell testcaseCell = row.getCell(0);
            Cell taskGroupCell = row.getCell(3);
            Cell taskIdCell = row.getCell(2);

            if (testcaseCell == null || taskGroupCell == null || taskIdCell == null) continue;

            String tc = testcaseCell.getStringCellValue().trim();
            String taskGroup = taskGroupCell.getStringCellValue().trim();
            String taskId = taskIdCell.getStringCellValue().trim();

            if (tc.equalsIgnoreCase(testcase)) {
                taskGroupMap.computeIfAbsent(taskGroup, k -> new ArrayList<>()).add(taskId);
            }
        }

        workbook.close();
        fis.close();
        return taskGroupMap;
    }
    // Stub methods for Selenium actions
    public static void SettingtheTaskGroupfromExcel(String taskGroupId) throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        System.out.println("Setting task group: " + taskGroupId);
        // Settings Button
        Thread.sleep(3000);
        // Wait until inner button inside shadow root exists
        new WebDriverWait(driver, Duration.ofSeconds(15)).until(d ->
                Boolean.TRUE.equals(((JavascriptExecutor) d).executeScript(
                        "const host = document.querySelector('ion-button[data-component-id=\"action_settings_button\"]');" +
                                "return host && host.shadowRoot && host.shadowRoot.querySelector('button.button-native') !== null;"
                ))
        );

        // Get the inner button
        WebElement innerButton = (WebElement) js.executeScript(
                "const host = document.querySelector('ion-button[data-component-id=\"action_settings_button\"]');" +
                        "return host.shadowRoot.querySelector('button.button-native');"
        );

        if (innerButton != null) {
            js.executeScript("arguments[0].scrollIntoView(true);", innerButton);
            js.executeScript("arguments[0].click();", innerButton);
            System.out.println("✅ Settings button clicked successfully!");
        } else {
            System.out.println("❌ Inner button still not found.");
        }


        Thread.sleep(3000);
        // Task Group Button
        new WebDriverWait(driver, Duration.ofSeconds(15)).until(d ->
                ((JavascriptExecutor) d).executeScript(
                        "return document.querySelector('ion-col[data-component-id=\"taskgroup\"]') !== null"
                ).equals(true)
        );

        WebElement taskGroup = (WebElement) js.executeScript(
                "return document.querySelector('ion-col[data-component-id=\"taskgroup\"]');"
        );

        if (taskGroup != null) {
            js.executeScript("arguments[0].scrollIntoView(true);", taskGroup);
            js.executeScript("arguments[0].click();", taskGroup);
            System.out.println("✅ Task Group clicked successfully!");
        } else {
            System.out.println("❌ Task Group element not found.");
        }


        Thread.sleep(3000);
        // Task Group Value

        wait = new WebDriverWait(driver, Duration.ofSeconds(15));

        // Wait for input field
        WebElement inputField = wait.until(d ->
                d.findElement(By.cssSelector("input[data-component-id='taskgroup_lookupurl']"))
        );

        // Enter value
        inputField.sendKeys(taskGroupId);

        // Option 1: Press Enter
        inputField.sendKeys(Keys.ENTER);

        WMSettingsclickDoneButton();

    }
    public static void WMSettingsclickDoneButton() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        System.out.println("WMSettingsclickDoneButton");
        try {
            // Step 1: Locate the ion-button with data-component-id
            WebElement shadowHost = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("ion-button[data-component-id='action_done_button']")
            ));

            // Step 2: Access shadow root
            WebElement innerButton = (WebElement) js.executeScript(
                    "return arguments[0].shadowRoot.querySelector('button.button-native');", shadowHost
            );

            // Step 3: Click the inner button
            if (innerButton != null) {
                js.executeScript("arguments[0].scrollIntoView(true);", innerButton);
                js.executeScript("arguments[0].click();", innerButton);
                System.out.println("✅ 'Done' button clicked successfully!");
            } else {
                System.out.println("❌ Inner button not found inside shadow DOM.");
            }
        } catch (Exception e) {
            System.err.println("❌ Error clicking 'Done' button: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void SearchMenuWM(String Keyword, String id)  {
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;




        int maxRetries = 6; // Try up to 2 times (1 initial + 1 retry)
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            System.out.println("⏳ Waiting 10 seconds before refreshing...");

            try {
                Thread.sleep(10000); // Wait 1 minute
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

//                // 🔄 Click the refresh button inside shadow DOM
//                WebElement refreshHost = driver.findElement(By.cssSelector("ion-button.refresh-button"));
//                js = (JavascriptExecutor) driver;
//                WebElement refreshButton = (WebElement) js.executeScript(
//                        "return arguments[0].shadowRoot.querySelector('button.button-native')", refreshHost);
//                refreshButton.click();
//                System.out.println("🔄 Refresh button clicked.");

            // Locate using data-component-id
            WebElement refreshBtn = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.cssSelector("ion-button[data-component-id='refresh']")
                    )
            );

            // Click the button
            refreshBtn.click();

            // Optional: verify action or add logging
            System.out.println("Refresh button clicked successfully!");

            // Optional: wait for UI to settle
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            try {
                WebElement shadowHost = wait1.until(ExpectedConditions.presenceOfElementLocated(
                        By.cssSelector("ion-button[data-component-id='menu-toggle-button']")
                ));
                SearchContext shadowRoot = (SearchContext) js.executeScript("return arguments[0].shadowRoot", shadowHost);
                WebElement nativeButton = shadowRoot.findElement(By.cssSelector("button.button-native"));

// wait for overlay to disappear
                wait1.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("manh-overlay-container")));

// click via JS to avoid interception
                js.executeScript("arguments[0].click();", nativeButton);

                System.out.println("Menu toggle button clicked.");




                break;
            }catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
                e.printStackTrace(System.err);


            }


        }




        try {
            // Locate the inner input directly under ion-input
            WebElement innerInput = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("ion-input[data-component-id='search-input'] input.native-input")
            ));

            wait.until(ExpectedConditions.elementToBeClickable(innerInput));

            innerInput.clear();
            innerInput.sendKeys(Keyword);
            System.out.println("✅ Search Done: " + Keyword);

        } catch (Exception e) {
            System.err.println("❌ Error interacting with search input: " + e.getMessage());
            e.printStackTrace();
        }
        try {


            // Wait for the button to be present and visible
            WebElement element = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("button#wmMobile[data-component-id=" + id + "]")
            ));


            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block: 'center'});", element
            );

            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].click();", element
            );

            System.out.println("Clicked element with id: " + id);
            ArrayList<String> tabs = new ArrayList<>(driver.getWindowHandles());
            driver.switchTo().window(tabs.get(1));

        } catch (Exception e) {

            System.err.println("Failed to click element with id: " + id);
            e.printStackTrace();

        }


    }

    static void backWMMobie() throws InterruptedException {
        // Wait until the ion-buttons container is present
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        WebElement backButton = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("ion-buttons[data-component-id='action_back_button']")
        ));

// Scroll into view to ensure visibility
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", backButton);

// Click the button twice using JavaScript

        // js.executeScript("arguments[0].click();", backButton);
        Thread.sleep(300); // brief pause between clicks
        js.executeScript("arguments[0].click();", backButton);

        System.out.println("Back button clicked twice successfully.");
    }



    static void SearchInWmMobile(String Transaction, String ComponentId)  {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));


        try {


            WebElement searchInput = wait.until(ExpectedConditions.elementToBeClickable(
                    By.cssSelector("ion-searchbar[data-component-id='search'] input[type='search']")));

            // Clear any existing text
            searchInput.clear();

            // Type the search text
            searchInput.sendKeys(Transaction);

            // Optionally, press ENTER if the search requires submission
            searchInput.sendKeys(Keys.ENTER);


//            WebElement searchInput1 = wait.until(ExpectedConditions.elementToBeClickable(
//                    By.cssSelector("input.searchbar-input[placeholder='Search']")));
////                    By.xpath("//input[@type='search' and @placeholder='Search']")));
//            searchInput1.click();
//            searchInput1.clear();
//            Thread.sleep(3000);
//            searchInput1.sendKeys(Transaction);
        } catch (Exception e) {
            System.err.println("❌ Error in "+Transaction + e.getMessage());
            e.printStackTrace();
        }
        // Locate the ion-label using its data-component-id

        WebElement labelElement = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("ion-label[data-component-id='" + ComponentId + "']")
        ));

        // Scroll into view to ensure it's interactable
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", labelElement);

        // Click using JavaScript (in case native click doesn't work)
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", labelElement);

        System.out.println("Clicked on" +Transaction+" label.");


    }



    static String WMEnterDynamicCartID() throws InterruptedException {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        // Generate dynamic Cart ID: "PC" + 7 random digits
        String cartId = "PC" + String.format("%07d", new Random().nextInt(10000000));
        System.out.println("Generated Cart ID: " + cartId);

        // Wait for the input field to be present
        Thread.sleep(15000); //
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement inputField = wait.until(driver1 -> (WebElement) js.executeScript(
                "return document.querySelector('input[data-component-id=\"acceptpickcart_barcodetextfield_cartid\"]')"
        ));

        if (inputField != null) {
            inputField.clear(); // Optional: clear existing text
            inputField.sendKeys(cartId);
            inputField.sendKeys(Keys.ENTER);
            System.out.println("Entered Cart ID and pressed Enter.");
        } else {
            System.out.println("Input field for Cart ID not found.");
        }
        return cartId;

    }
    public static void clickTapToConfirmButton() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        try {
            // Step 1: Locate the shadow host (ion-button)
            WebElement shadowHost = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("ion-button[data-component-id='taptoverifydirectedcontainer_taptoconfirm_button']")
            ));

            // Step 2: Access the shadow root and find the inner native button
            WebElement innerButton = (WebElement) js.executeScript(
                    "return arguments[0].shadowRoot.querySelector('button.button-native');", shadowHost
            );

            // Step 3: Click the inner button
            if (innerButton != null) {
                js.executeScript("arguments[0].scrollIntoView(true);", innerButton);
                js.executeScript("arguments[0].click();", innerButton);
                System.out.println("✅ Tap to Confirm button clicked.");
            } else {
                System.out.println("❌ Inner button not found inside shadow DOM.");
            }
        } catch (Exception e) {
            System.err.println("❌ Error clicking Tap to Confirm button: " + e.getMessage());
        }
    }
    public static void clickTapToConfirmButton2() {

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        // Wait for the "Tap to Confirm" button to be clickable
        WebElement tapToConfirmButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[data-component-id='action_taptoconfirm_button']")));

        // Click the button
        tapToConfirmButton.click();
    }
    public static void SlotinputButton(String countId) {
        System.out.println("Slot input with ID: " + countId);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        // Wait for the input field to be clickable
        WebElement slotInput = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("input[data-component-id='acceptslot_barcodetextfield_slot']")
        ));

        // Click to focus
        slotInput.click();

        // Send slot ID and press Enter
        slotInput.sendKeys(countId);
        slotInput.sendKeys(Keys.ENTER);
    }
    public static boolean Nomoretasksdailogbox() throws InterruptedException {
        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));

            // Wait for the alert wrapper to appear
            WebElement alertWrapper = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("div.alert-wrapper.ion-overlay-wrapper")
            ));

            // Confirm the message text is correct
            WebElement message = alertWrapper.findElement(By.cssSelector("div.alert-message"));
            if (message.getText().contains("No more tasks to assign")) {
                // Find and click the OK button
                WebElement okButton = alertWrapper.findElement(By.xpath(".//button[span[text()='Ok']]"));
                okButton.click();
                System.out.println("Dialog detected and OK button clicked.");
                ClickEndcart();

                return true;
            }
        } catch (TimeoutException e) {
            // Dialog not present or not ready
        }
        return false;
    }
    static void ClickEndcart() throws InterruptedException {

        try {
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
            WebElement endCartButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("button[data-component-id='action_endcart_button']")));


            endCartButton.click();


        } catch (Exception e) {
        System.out.println("Failed EndCart" + e.getMessage());
    }

    }
    public static void ScanCartID(String cartId) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            WebElement cartInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("input[data-component-id='verifypickcart_barcodetextfield_scancart']")));

            cartInput.clear();
            cartInput.sendKeys(cartId);
            cartInput.sendKeys(Keys.ENTER);

        } catch (Exception e) {
            System.out.println("❌ Failed to scan Cart ID: " + e.getMessage());
        }


    }
    public static void ScanCartID2(String cartId) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            WebElement cartInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("input[data-component-id='acceptcart_barcodetextfield_cartid']")));

            cartInput.clear();
            cartInput.sendKeys(cartId);
            cartInput.sendKeys(Keys.ENTER);
            System.out.println(" Enter Cart ID: ");

        } catch (Exception e) {
            System.out.println("❌ Failed to scan Cart ID: " + e.getMessage());
        }


    }
    public static boolean clickOkAlertButton() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        try {
            WebElement okButton = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("//button[.//span[text()='Ok']]")));
            okButton.click();
            System.out.println("✅ Clicked 'Ok' alert button.");
            return true;
        } catch (TimeoutException e) {
            return false; // Alert not found
        } catch (Exception e) {
            System.out.println("❌ Error checking alert: " + e.getMessage());
            return false;
        }
    }
    public static void WmActionBack() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement backButton = wait.until(ExpectedConditions.presenceOfElementLocated(
                By.cssSelector("ion-buttons[data-component-id='action_back_button']")
        ));

// Scroll into view to ensure visibility
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", backButton);

// Click the button twice using JavaScript

        //  js.executeScript("arguments[0].click();", backButton);
        //// brief pause between clicks
        js.executeScript("arguments[0].click();", backButton);

        System.out.println("Back button clicked twice successfully.");

    }
    public static void WmActionSubmenuBack() {


        // Locate the Back button using its data-component-id
        WebElement backButton = driver.findElement(
                By.cssSelector("ion-button[data-component-id='action_submenu_back_button']")
        );

        // Scroll into view and click using JavaScript
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", backButton);
        js.executeScript("arguments[0].click();", backButton);

        System.out.println("✅ Clicked on 'Back' button.");


    }
    public static void Packlocation() {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {


            WebElement cartInput = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("input[data-component-id='acceptlocation_barcodetextfield_destinationlocation']")));

            cartInput.clear();
            cartInput.sendKeys(locationP);
            cartInput.sendKeys(Keys.ENTER);

            System.out.println("✅ Entered location value: " + locationP);


        } catch (Exception e) {
            System.err.println("❌ Error clicking 'Done' button: " + e.getMessage());
            e.printStackTrace();
        }

    }
    public static void SourceLocation() {
        // Locate the ion-col element and extract its text
        try {
            WebElement locationElement = driver.findElement(By.cssSelector("ion-col[data-component-id='acceptlocation_barcodetextfield_location']"));
            String rawLocation = locationElement.getText(); // e.g., "PKT-L1-01-12-20-B"

            // Remove hyphens
            String cleanedLocation = rawLocation.replace("-", ""); // Result: "PKTL1011220B"

            // Locate the input field and enter the cleaned value
            WebElement inputField = driver.findElement(By.cssSelector("input[data-component-id='acceptlocation_barcodetextfield_scanlocation']"));
            // inputField.clear();
            inputField.sendKeys(cleanedLocation);
            inputField.sendKeys(Keys.ENTER);
            System.out.println("Add Location Barcode ");
        } catch (Exception e) {
            System.out.println("❌ Failed to Add Location Barcode " + e.getMessage());
        }


    }
    public static void ItemBarcode() throws IOException {
        // Locate the ion-col element and extract its text
        String token = null;
        try {
            token = getAuthTokenFromExcel();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        if (token == null) {
            System.err.println("❌ Failed to retrieve access token.");
            return;
        }




        try {
            WebElement itemElement = driver.findElement(By.cssSelector("ion-col[data-component-id='acceptitem_barcodetextfield_item']"));
            String itemRaw = itemElement.getText(); // e.g., "0007-1-0-64"
            // String itemCleaned = itemRaw.replace("-", ""); // Result: "00071064"




            String itemCleaned = searchItemMaster(itemRaw,token);

            //String itemCleaned = "0000071064"; // Result: "00071064"

            WebElement itemInput = driver.findElement(By.cssSelector("input[data-component-id='acceptitem_barcodetextfield_scanitem']"));
            itemInput.sendKeys(itemCleaned);
            itemInput.sendKeys(Keys.ENTER);
            System.out.println("Add ItemBarcode ");
        } catch (Exception e) {
            System.out.println("❌ Failed to Add ItemBarcode " + e.getMessage());
        }


    }

    public static void EnterUnit() {
        // Locate the ion-col element and extract its text
        try {
            // Locate the ion-col element and extract its text
            WebElement quantityElement = driver.findElement(By.cssSelector("ion-col[data-component-id='acceptquantity_naturalquantityfield_need']"));
            String quantityRaw = quantityElement.getText(); // e.g., "6 UNIT"

            // Remove non-digit characters to isolate the number
            String quantityCleaned = quantityRaw.replaceAll("[^0-9]", ""); // Result: "6"

            // Locate the input field and enter the cleaned quantity
            WebElement quantityInput = driver.findElement(By.cssSelector("input[data-component-id='acceptquantity_naturalquantityfield_unit']"));
            quantityInput.sendKeys(quantityCleaned);
            quantityInput.sendKeys(Keys.ENTER);
            System.out.println("Successfully  EnterUnit ");
        } catch (Exception e) {
            System.out.println("❌ Failed to EnterUnit " + e.getMessage());
        }
    }
    public static void EnterOlpn() {
        // Locate the ion-col element and extract its text
        try {
            // Locate the ion-col element and extract its text
            WebElement olpnElement = driver.findElement(By.cssSelector("ion-col[data-component-id='confirmolpntocompletepick_barcodetextfield_olpn']"));
            String olpnValue = olpnElement.getText(); // e.g., "KA701311001708"

            // Input oLPN value
            WebElement olpnInput = driver.findElement(By.cssSelector("input[data-component-id='confirmolpntocompletepick_barcodetextfield_scanolpn']"));
            olpnInput.sendKeys(olpnValue);
            olpnInput.sendKeys(Keys.ENTER);
            System.out.println("Successfully  EnterOlpn ");
        } catch (Exception e) {
            System.out.println("❌ Failed to EnterOlpn " + e.getMessage());
        }
    }
    public static boolean isElementPresent(String dataComponentId) {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            driver.findElement(By.cssSelector("[data-component-id='" + dataComponentId + "']"));
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }


    public static String getAuthTokenFromExcel() throws IOException {
        ExcelReader reader = new ExcelReader();

// By header name
        String LOGIN_URL = reader.getCellValueByHeader(1, "LOGIN_URL");
        String UIUsername = reader.getCellValueByHeader(1, "username");
        String UIPassword = reader.getCellValueByHeader(1, "password");

        reader.close();


        // Step 2: Call token API
        OkHttpClient client = new OkHttpClient();
        MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
        RequestBody body = RequestBody.create(mediaType,
                "grant_type=password&username=" + UIUsername + "&password=" + UIPassword);

        Request request = new Request.Builder()
                .url(LOGIN_URL)
                .method("POST", body)
                .addHeader("Content-Type", "application/x-www-form-urlencoded")
                .addHeader("Authorization", "Basic dWpkc3N0YWdlMTpFYXJ0aC1Nb29uLVN1bjE=")
                .build();

        Response response = client.newCall(request).execute();
        String responseBody = response.body() != null ? response.body().string() : null;
        JsonObject json = JsonParser.parseString(responseBody).getAsJsonObject();

        return json.has("access_token") ? json.get("access_token").getAsString() : null;
    }
    public static String searchItemMaster(String itemId, String token) throws IOException {
        ExcelReader reader = new ExcelReader();

        // Read environment headers
        String BASE_URL = reader.getCellValueByHeader(1, "BASE_URL");
        String SelectedOrganization = reader.getCellValueByHeader(1, "SelectedOrganization");
        String SelectedLocation = reader.getCellValueByHeader(1, "SelectedLocation");

        reader.close();

        // Build request body
        JsonObject bodyJson = new JsonObject();
        bodyJson.addProperty("Query", "ItemId in ('" + itemId + "')");
        String body = bodyJson.toString();

        // Prepare request
        OkHttpClient client = new OkHttpClient();
        MediaType mediaType = MediaType.parse("application/json");
        RequestBody requestBody = RequestBody.create(mediaType, body);

        Request request = new Request.Builder()
                .url(BASE_URL + "/item-master/api/item-master/item/search?size=200")
                .method("POST", requestBody)
                .addHeader("Content-Type", "application/json")
                .addHeader("SelectedOrganization", SelectedOrganization)
                .addHeader("SelectedLocation", SelectedLocation)
                .addHeader("Authorization", "Bearer " + token)
                .build();

        Response response = client.newCall(request).execute();
        return response.body() != null ? response.body().string() : null;
    }

}