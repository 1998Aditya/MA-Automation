//package MA_MSG_Suite_OB;
//
//import com.google.gson.*;
//import io.github.bonigarcia.wdm.WebDriverManager;
//import okhttp3.*;
//import org.apache.poi.ss.usermodel.*;
//import org.apache.poi.util.Units;
//import org.apache.poi.xssf.usermodel.XSSFWorkbook;
//import org.apache.poi.xwpf.usermodel.Document;
//import org.apache.poi.xwpf.usermodel.XWPFDocument;
//import org.apache.poi.xwpf.usermodel.XWPFParagraph;
//import org.apache.poi.xwpf.usermodel.XWPFRun;
//import org.openqa.selenium.*;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.chrome.ChromeOptions;
//import org.openqa.selenium.support.ui.ExpectedConditions;
//import org.openqa.selenium.support.ui.WebDriverWait;
//
//import java.io.*;
//import java.time.Duration;
//import java.util.*;
//
//import static javax.swing.UIManager.getString;
//
//public class Main6a_WaveToReleaseTask {
//    public static String statusText;
//    public static XWPFDocument document = new XWPFDocument();
//    public static WebDriver driver;
//    public static String waveNumber;
//
//    public static String docPath;
//    public static Map<String, String> opsToWaveMap = new HashMap<>(); // OPS -> WaveNum
//    public static Map<String, List<String>> waveTaskMap = new HashMap<>(); // Wave -> Task IDs
//    public static Map<String, List<String>> waveOlpnMap = new HashMap<>(); // Wave -> OLPN IDs
//
//
//        public static void main(String filePath,String testcase,String env) {
//
//        try {
////          Extract OPS
//            String path = filePath;
//            String testcaseToRun = testcase;
//            String ops = getOpsForTestcase(path, testcaseToRun);
//            System.out.println("Processing OPS: " + ops);
//
////         Step 3: Login once
//
//            WebDriverManager.chromedriver().setup();
//            ChromeOptions options = new ChromeOptions();
//            options.addArguments("--start-maximized");
//
//            driver = new ChromeDriver(options);
//            driver.manage().window().maximize();
//            Main1_URL_Login1 login1 = new Main1_URL_Login1(driver, env);
//            login1.execute();
//            System.out.println("login done:\n");
//            DocumentName("Testcase",filePath);
//
//            try {
//                RunOPS(ops); // Generate Wave Number
//              //  WavestatusWait(filePath,testcase);   // Update Wave status and Generate Task
//            } catch (Exception e) {
//                System.err.println("Error while processing OPS: " + ops);
//                e.printStackTrace();
//            }
//
////            GenerateTask();
////            System.err.println("Executing MainD_WaveToExcel1 after 20 sec");
////            Thread.sleep(20000);
////            Main6b_WaveToExcel.main(waveNumber,path, testcaseToRun);
////            Thread.sleep(2000);
////            WaveSelectionAndRelatedlinks();
////            Thread.sleep(2000);
////            Allocation();
////            Thread.sleep(2000);
////            navigateTillWaveRuns1();
////            Thread.sleep(2000);
////            WaveSelectionAndRelatedlinks();
////            Thread.sleep(2000);
////            clickOLPNs();
////            Thread.sleep(2000);
//
////            navigateTillWaveRuns1();
////            Thread.sleep(2000);
////            WaveSelectionAndRelatedlinks();
////            Thread.sleep(2000);
////            clickorders();
////
////
//
////            navigateTillWaveRuns1();
////            Thread.sleep(2000);
////            WaveSelectionAndRelatedlinks();
////            Thread.sleep(2000);
////            clickTasks();
////            Thread.sleep(2000);
//
//
//
//
//
////            if (driver != null) {
////                driver.quit();
////            }
//
//        } catch (Exception e) {
//            System.err.println("❌ Error occurred: " + e.getMessage());
//            e.printStackTrace();
//
//            updateOpsStatus(filePath, testcase, "Failed");
//
//        }
//    }
//
//
//    public static String getOpsForTestcase(String path, String testcaseToRun) throws IOException {
//        try (FileInputStream fis = new FileInputStream(path);
//             Workbook workbook = new XSSFWorkbook(fis)) {
//
//            Sheet sheet = workbook.getSheet("OPS_Tab");
//            if (sheet == null) {
//                System.out.println("❌ Sheet 'OPS & Wave Num' not found!");
//                return null;
//            }
//
//            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
//                Row row = sheet.getRow(i);
//                if (row == null) continue;
//
//                String testcase = getCellValueAsString(row.getCell(0));
//                if (testcase != null && testcase.trim().equalsIgnoreCase(testcaseToRun)) {
//                    return getCellValueAsString(row.getCell(1)); // Column 1 = OPS
//                }
//            }
//        }
//        return null; // No matching testcase found
//    }
//    private static String getCellValueAsString(Cell cell) {
//        if (cell == null) return "";
//        switch (cell.getCellType()) {
//            case STRING:
//                return cell.getStringCellValue().trim();
//            case NUMERIC:
//                return String.valueOf((int) cell.getNumericCellValue()).trim();
//            case BOOLEAN:
//                return String.valueOf(cell.getBooleanCellValue()).trim();
//            case FORMULA:
//                return cell.getCellFormula().trim();
//            default:
//                return "";
//        }
//    }
//    public static void fetchAndWriteTaskOlpnData(String token,String filePath) throws IOException {
//        try (FileInputStream fis = new FileInputStream(filePath);
//             Workbook workbook = new XSSFWorkbook(fis)) {
//
//            Sheet taskSheet = workbook.getSheet("Tasks");
//            if (taskSheet == null) {
//                System.err.println("❌ Sheet 'Tasks' not found.");
//                return;
//            }
//
//            // ✅ Print all values in row 1 (second row)
//            Row row1 = taskSheet.getRow(1);
//            if (row1 != null) {
//                System.out.print("Row 1 values: ");
//                for (int c = 0; c < row1.getLastCellNum(); c++) {
//                    Cell cell = row1.getCell(c);
//                    String value = (cell == null) ? "" : cell.toString();
//                    System.out.print(value + " | ");
//                }
//                System.out.println();
//            }
//
//            // ✅ Start writing from row 1 (second row)
//            int taskRowIndex = 1; // Force writing in second row
//
//            // ✅ Read wave numbers from column 0 of Tasks sheet
//            for (int i = 1; i <= taskSheet.getLastRowNum(); i++) {
//                Row row = taskSheet.getRow(i);
//                if (row == null) continue;
//
//                Cell waveCell = row.getCell(0); // Column 0
//                if (waveCell == null) continue;
//
//                String waveNumber = waveCell.getStringCellValue().trim();
//                if (waveNumber.isEmpty()) continue;
//
//
//
//
//                // ✅ Fetch Task IDs and OLPN IDs for this wave
//                List<String> taskIds = fetchIds(waveNumber, "task", "GenerationNumberId", token, "com-manh-cp-task", "TaskId");
//                List<String> olpnIds = fetchIds(waveNumber, "olpn", "OrderPlanningRunId", token, "com-manh-cp-pickpack", "OlpnId");
//
//                System.out.println("Wave: " + waveNumber + " | Tasks: " + taskIds + " | OLPNs: " + olpnIds);
//
//                waveTaskMap.put(waveNumber, taskIds);
//                waveOlpnMap.put(waveNumber, olpnIds);
//
//                String olpnId = olpnIds.isEmpty() ? "" : olpnIds.get(0); // Take first OLPN for the wave
//
//                // ✅ Overwrite row 1 instead of appending
//                for (String taskId : taskIds) {
//                    Row newRow = taskSheet.getRow(taskRowIndex);
//                    if (newRow == null) {
//                        newRow = taskSheet.createRow(taskRowIndex);
//                    }
//                    newRow.createCell(1).setCellValue(waveNumber); // Column B
//                    newRow.createCell(2).setCellValue(taskId);     // Column C
//                    newRow.createCell(8).setCellValue(olpnId);     // Column I
//                    newRow.createCell(3).setCellValue("");         // Column D
//                    taskRowIndex++; // Move to next row if multiple tasks
//                }
//            }
//
//            // ✅ Save changes
//            try (FileOutputStream fos = new FileOutputStream(filePath)) {
//                workbook.write(fos);
//            }
//            System.out.println("✅ Task IDs and OLPN IDs written starting from row 2.");
//        }
//    }
//    public static List<String> fetchIds(String waveNumber, String viewName, String attributeId, String token, String componentName, String idKey) {
//        List<String> ids = new ArrayList<>();
//        int maxRetries = 3;
//
//        for (int attempt = 1; attempt <= maxRetries; attempt++) {
//            try {
//                OkHttpClient client = new OkHttpClient();
//                MediaType mediaType = MediaType.parse("application/json");
//
//                JsonObject filter = new JsonObject();
//                filter.addProperty("ViewName", viewName);
//                filter.addProperty("AttributeId", attributeId);
//                filter.add("FilterValues", new Gson().toJsonTree(List.of(waveNumber.trim())));
//                filter.addProperty("requiredFilter", false);
//                filter.addProperty("Operator", "=");
//
//                JsonObject body = new JsonObject();
//                body.addProperty("ViewName", viewName.equalsIgnoreCase("olpn") ? "DMOlpn" : "Task");
//                body.add("Filters", new Gson().toJsonTree(List.of(filter)));
//                body.addProperty("ComponentName", componentName);
//                body.addProperty("Size", 100);
//                body.addProperty("TimeZone", "Europe/Paris");
//                RequestBody requestBody = RequestBody.create(mediaType, body.toString());
//
//                Request request = new Request.Builder()
//                        .url("https://ujdss.sce.manh.com/dmui-facade/api/dmui-facade/entity/search")
//                        .post(requestBody)
//                        .addHeader("Content-Type", "application/json")
//                        .addHeader("Authorization", "Bearer " + token)
//                        .addHeader("SelectedOrganization", "HEERLEN51")
//                        .addHeader("SelectedLocation", "HEERLEN51")
//                        .build();
//
//                Response response = client.newCall(request).execute();
//                String responseBody = response.body() != null ? response.body().string() : "No response body";
//
//                System.out.println("\n🔍 Attempt " + attempt + " for wave: " + waveNumber);
//                System.out.println("Request Body: " + body.toString());
//                System.out.println("Response Code: " + response.code());
//                System.out.println("Response Body: " + responseBody);
//
//                if (!response.isSuccessful()) {
//                    System.err.println("❌ Failed to fetch " + idKey + " (HTTP " + response.code() + ")");
//                    if (response.code() == 500 && attempt < maxRetries) {
//                        System.out.println("🔁 Retrying...");
//                        Thread.sleep(1000);
//                        continue;
//                    } else {
//                        break;
//                    }
//                }
//
//                JsonObject json = JsonParser.parseString(responseBody).getAsJsonObject();
//                if (json.has("data")) {
//                    JsonObject dataObject = json.getAsJsonObject("data");
//                    if (dataObject.has("Results")) {
//                        JsonArray results = dataObject.getAsJsonArray("Results");
//                        for (JsonElement element : results) {
//                            JsonObject obj = element.getAsJsonObject();
//                            if (obj.has(idKey)) {
//                                ids.add(obj.get(idKey).getAsString());
//                            }
//                        }
//                    }
//                }
//
//                break;
//
//            } catch (Exception e) {
//                System.err.println("❌ Exception fetching " + idKey + " (Attempt " + attempt + "): " + e.getMessage());
//            }
//        }
////        List<String> taskIds = fetchIds( "task", "GenerationNumberId", "com-manh-cp-task", "TaskId");
////        List<String> olpnIds = fetchIds( "olpn", "OrderPlanningRunId", "com-manh-cp-pickpack", "OlpnId");
//
//        System.out.println("✅ Fetched " + ids.size() + " " + idKey + "(s) for wave: " + waveNumber);
//        return ids;
//    }
//
//    public static void SearchMenu(String Keyword, String id)  {
//        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//
//
//
//            int maxRetries = 6; // Try up to 2 times (1 initial + 1 retry)
//            for (int attempt = 1; attempt <= maxRetries; attempt++) {
//                System.out.println("⏳ Waiting 10 seconds before refreshing...");
//
//                try {
//                    Thread.sleep(10000); // Wait 1 minute
//                } catch (InterruptedException e) {
//                    throw new RuntimeException(e);
//                }
//
////                // 🔄 Click the refresh button inside shadow DOM
////                WebElement refreshHost = driver.findElement(By.cssSelector("ion-button.refresh-button"));
////                js = (JavascriptExecutor) driver;
////                WebElement refreshButton = (WebElement) js.executeScript(
////                        "return arguments[0].shadowRoot.querySelector('button.button-native')", refreshHost);
////                refreshButton.click();
////                System.out.println("🔄 Refresh button clicked.");
//
//                // Locate using data-component-id
//                WebElement refreshBtn = wait.until(
//                        ExpectedConditions.elementToBeClickable(
//                                By.cssSelector("ion-button[data-component-id='refresh']")
//                        )
//                );
//
//                // Click the button
//                refreshBtn.click();
//
//                // Optional: verify action or add logging
//                System.out.println("Refresh button clicked successfully!");
//
//                // Optional: wait for UI to settle
//                try {
//                    Thread.sleep(3000);
//                } catch (InterruptedException e) {
//                    throw new RuntimeException(e);
//                }
//
//                try {
//                WebElement shadowHost = wait1.until(ExpectedConditions.presenceOfElementLocated(
//                        By.cssSelector("ion-button[data-component-id='menu-toggle-button']")
//                ));
//                SearchContext shadowRoot = (SearchContext) js.executeScript("return arguments[0].shadowRoot", shadowHost);
//                WebElement nativeButton = shadowRoot.findElement(By.cssSelector("button.button-native"));
//
//// wait for overlay to disappear
//                wait1.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("manh-overlay-container")));
//
//// click via JS to avoid interception
//                js.executeScript("arguments[0].click();", nativeButton);
//
//                System.out.println("Menu toggle button clicked.");
//                    break;
//            }catch (Exception e) {
//                System.err.println("Error: " + e.getMessage());
//                e.printStackTrace(System.err);
//
//            }
//            }
//
//
//
//        try {
//            // Locate the inner input directly under ion-input
//            WebElement innerInput = wait.until(ExpectedConditions.presenceOfElementLocated(
//                    By.cssSelector("ion-input[data-component-id='search-input'] input.native-input")
//            ));
//
//            wait.until(ExpectedConditions.elementToBeClickable(innerInput));
//
//            innerInput.clear();
//            innerInput.sendKeys(Keyword);
//            System.out.println("✅ Search Done: " + Keyword);
//
//        } catch (Exception e) {
//            System.err.println("❌ Error interacting with search input: " + e.getMessage());
//            e.printStackTrace();
//        }
//        try {
//
//            WebElement element = wait.until(
//                    ExpectedConditions.elementToBeClickable(By.id(id))
//            );
//
//            ((JavascriptExecutor) driver).executeScript(
//                    "arguments[0].scrollIntoView({block: 'center'});", element
//            );
//
//            ((JavascriptExecutor) driver).executeScript(
//                    "arguments[0].click();", element
//            );
//
//            System.out.println("Clicked element with id: " + id);
//
//        } catch (Exception e) {
//
//            System.err.println("Failed to click element with id: " + id);
//            e.printStackTrace();
//
//        }
//
//
//
//    }
//
//
//
//    public static void RunOPS(String OPS) throws InterruptedException, IOException {
//        System.out.println("Run OPS starts");
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//        Thread.sleep(5000);
//
//        System.out.println("OPS: " + OPS);
//
//        SearchMenu("Order Planning Strategy","orderPlanningStrategy");
//
//
//        //
//        //
//        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//        System.out.println("closing Menu while RunOPS");
//
//        WebElement closeIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                By.cssSelector("ion-icon[data-component-id='close']"))
//        );
//
//        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", closeIcon);
//
//
//
//        System.out.println("closing Menu while RunOPS Done");
//
//
//        // Wait for page to load
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println("Order Planning Strategy button clicked.");
//
//
//
//
//
//// Wait for page to load
//        try {
//            Thread.sleep(5000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        // Expand the item search section
//        WebElement filterBtnHost = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//ion-button[contains(@class,\"toggle-button\")])[3]")));
//        JavascriptExecutor jse = (JavascriptExecutor)driver;
//        // WebElement expandButton =(WebElement) jse.executeScript("return arguments[0].shadowRoot",filterBtnHost);
//        WebElement expandButton = (WebElement) jse.executeScript(
//                "let btn = arguments[0].shadowRoot.querySelector('.button-inner');" +
//                        " btn.click(); " ,
//                filterBtnHost);
//
//
//
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Wait setup
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
//        Thread.sleep(500);
//
//// Check if 'chevron-up' is already present
//        List<WebElement> chevronUpButtons = driver.findElements(
//                By.cssSelector("ion-button[data-component-id='OrderPlanningStrategy-Name-chevron-up']")
//        );
//
//        if (!chevronUpButtons.isEmpty()) {
//            System.out.println("Chevron-up is already present. Skipping click.");
//
//        } else {
//            // Wait until the 'chevron-down' button is clickable
//            WebElement expandButton1 = wait.until(
//                    ExpectedConditions.elementToBeClickable(
//                            By.cssSelector("ion-button[data-component-id='OrderPlanningStrategy-Name-chevron-down']")
//                    )
//            );
//
//            // Scroll into view
//            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", expandButton1);
//            Thread.sleep(500); // Optional smooth scroll delay
//
//            // Click the button
//            expandButton1.click();
//            System.out.println("Chevron-down button clicked using native click.");
//
//        }
//
//
//
//
//
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Locate the input field inside ion-input with PlanningStrategyId
//        WebElement planningStrategyInputField = driver.findElement(By.xpath(
//                "//ion-input[@data-component-id='PlanningStrategyId']//input[contains(@class,'native-input')]"
//
//        ));
//        try {
//            Thread.sleep(3000); // Wait 3 seconds before next OPS
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        planningStrategyInputField = wait.until(
//                ExpectedConditions.elementToBeClickable(By.xpath(
//                        "//ion-input[@data-component-id='PlanningStrategyId']//input"
//                ))
//        );
//
//        if (OPS != null && !OPS.isEmpty()) {
//            planningStrategyInputField.click();
//            //planningStrategyInputField.clear();
//            planningStrategyInputField.sendKeys(Keys.CONTROL + "a");
//            planningStrategyInputField.sendKeys(Keys.DELETE);
//            try {
//                Thread.sleep(3000); // Wait 3 seconds before next OPS
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//            // planningStrategyInputField.clear();
//            planningStrategyInputField.sendKeys(Keys.CONTROL + "a");
//            planningStrategyInputField.sendKeys(Keys.DELETE);
//            planningStrategyInputField.sendKeys(OPS);
//            planningStrategyInputField.sendKeys(Keys.ENTER);
//
//        }
//
//
//
//        System.out.println("Planning Strategy ID entered: " + OPS);
//
//
//
//
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Locate the button using its data-component-id
//        WebElement actionClosedButton = driver.findElement(
//                By.cssSelector("button[data-component-id='action-closed']")
//        );
//
//// Scroll into view and click using JavaScript
//        JavascriptExecutor js3 = (JavascriptExecutor) driver;
//        js3.executeScript("arguments[0].scrollIntoView(true);", actionClosedButton);
//        try {
//            Thread.sleep(500); // Optional smooth scroll delay
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Perform the click
//        js3.executeScript("arguments[0].click();", actionClosedButton);
//        System.out.println("Action Closed button clicked.");
//
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Locate the button using its data-component-id
//        WebElement runWaveButton = driver.findElement(
//                By.cssSelector("button[data-component-id='RunWave']")
//        );
//
//// Scroll into view and click using JavaScript
//        JavascriptExecutor js4 = (JavascriptExecutor) driver;
//        js4.executeScript("arguments[0].scrollIntoView(true);", runWaveButton);
//        try {
//            Thread.sleep(500); // Optional smooth scroll delay
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Perform the click
//        js4.executeScript("arguments[0].click();", runWaveButton);
//
//        System.out.println("Run Wave button clicked.");
//
//        WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(5));
//
//// Wait for the pop-up to appear
//        WebElement toastMessage = wait5.until(ExpectedConditions.visibilityOfElementLocated(
//                By.cssSelector(".toast-message .text-wrap")));
//
//// Get the full message text
//        String popupText = toastMessage.getText(); // e.g., "Wave W2025091/7412100000012 is submitted (info)"
//
//// Extract the wave number using regex
//        waveNumber = popupText.replaceAll(".*Wave\\s+(\\S+)\\s+is submitted.*", "$1");
//
//// Print the wave number
//        System.out.println("Wave Number: " + waveNumber);
//
//
//        opsToWaveMap.put(OPS, waveNumber); // store mapping
//
//
//    }
//    public static void WavestatusWait(String filePath, String testcase) throws InterruptedException, IOException {
//        System.out.println("WaveStatus starts");
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        /* Implement logic */
//
//            Thread.sleep(3000);
//
//        SearchMenu("Wave Run","OrderPlanningRunStrategy");
//
//
//// Optional: wait for UI to update
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//
//
//
//
////        WebElement closeIcon = wait.until(ExpectedConditions.elementToBeClickable(By.id("close-menu-button")));
//////        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("close-menu-button")));
////        // Check if the icon is displayed (i.e., menu is open)
////        if (closeIcon.isDisplayed()) {
////             js = (JavascriptExecutor) driver;
////            js.executeScript("arguments[0].click();", closeIcon);
////        } else {
////            System.out.println("Close icon is not visible. Menu might already be closed.");
////        }
//
////
//        //
//        // Wait for page to load
//
//            Thread.sleep(5000);
//
//
//        // Expand the item search section
//        WebElement filterBtnHost = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//ion-button[contains(@class,\"toggle-button\")])[3]")));
//        JavascriptExecutor jse = (JavascriptExecutor) driver;
//        // WebElement expandButton =(WebElement) jse.executeScript("return arguments[0].shadowRoot",filterBtnHost);
//        WebElement expandButton = (WebElement) jse.executeScript(
//                "let btn = arguments[0].shadowRoot.querySelector('.button-inner');" +
//                        " btn.click(); ",
//                filterBtnHost);
////
//        //
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Wait until the button is clickable using its data-component-id
//      //  WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10));
//        WebElement expandButton1 = wait.until(
//                ExpectedConditions.elementToBeClickable(
//                        By.cssSelector("ion-button[data-component-id='OrderPlanningRunStrategy-Waverun-chevron-down']")
//                )
//        );
//
//// Scroll into view (optional)
//        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", expandButton1);
//        try {
//            Thread.sleep(500); // Optional smooth scroll delay
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Use native click instead of JavaScript
//        expandButton1.click();
//        System.out.println("Wave Run chevron-down button clicked using native click.");
//
//
////
//        //
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//
//        WebElement orderPlanningRunInputField = wait.until(
//                ExpectedConditions.elementToBeClickable(By.xpath("//ion-input[@data-component-id='OrderPlanningRunId-lookup-dialog-filter-input']//input"))
//        );
//
//
//// Define the value to enter
//
//
//// Enter the value
//        if (waveNumber != null && !waveNumber.isEmpty()) {
//            orderPlanningRunInputField.click();     // Focus the field
//            orderPlanningRunInputField.clear();     // Clear any existing value
//            orderPlanningRunInputField.sendKeys(waveNumber);// Type the value
//            orderPlanningRunInputField.sendKeys(Keys.ENTER);         // Optionally press Enter
//        }
//
//        System.out.println("Order Planning Run ID entered: " + waveNumber);
//        int maxRetries = 6; // Try up to 2 times (1 initial + 1 retry)
//        for (int attempt = 1; attempt <= maxRetries; attempt++) {
//            System.out.println("⏳ Waiting 30 seconds before refreshing...");
//
//            try {
//                Thread.sleep(30000); // Wait 1 minute
//            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
//            }
//
//
//
//// 2. Wait until the shadow root contains the native button
//            WebElement refreshButton = wait.until(driver1 -> {
//                WebElement host = driver1.findElement(By.cssSelector("ion-button.refresh-button"));
//                Object element = ((JavascriptExecutor) driver1).executeScript(
//                        "return arguments[0].shadowRoot.querySelector('button.button-native')", host
//                );
//                return (WebElement) element;
//            });
//
//// 3. Ensure it is clickable before clicking
//            wait.until(ExpectedConditions.elementToBeClickable(refreshButton));
//            refreshButton.click();
//
//
//
//
//
//
//
//
//
////
////            // 🔄 Click the refresh button inside shadow DOM
////            WebElement refreshHost = driver.findElement(By.cssSelector("ion-button.refresh-button"));
////            js = (JavascriptExecutor) driver;
////            WebElement refreshButton = (WebElement) js.executeScript(
////                    "return arguments[0].shadowRoot.querySelector('button.button-native')", refreshHost);
////            refreshButton.click();
////            System.out.println("🔄 Refresh button clicked.");
//
//            // Optional: wait for UI to settle
//            try {
//                Thread.sleep(3000);
//            } catch (InterruptedException e) {
//                throw new RuntimeException(e);
//            }
//
//            // 📌 Check status
//            WebElement statusElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                    By.cssSelector("div[data-component-id='PlanningStatusDescription']")));
//
//            statusText = statusElement.getText().trim();
//            System.out.println("📌 Planning Status: " + statusText);
//
//           // markOpsCompleted(filePath, testcase, statusText);
//           // markOpsCompleted(filePath, testcase, "Completed");
//
//            //markOpsCompleted(path, testcaseToRun, statusText);
//
//
//            if ("Completed".equalsIgnoreCase(statusText)) {
//                System.out.println("✅ Status is Completed: OK"+statusText);
//
//                updateOpsStatus(filePath, testcase, statusText);
//
//                break; // Exit loop and continue with next actions
//            } else if ("Cancelled".equalsIgnoreCase(statusText)) {
//                System.out.println("❌ Status is Cancelled: skipping further actions.");
//                updateOpsStatus(filePath, testcase, statusText);
//
//                captureScreenshot("Wave Status");
//                captureAllCardsScreenshots();
//                saveDocument(docPath);
//                return; // Exit method
//
//            } else if ("Started".equalsIgnoreCase(statusText) && attempt < maxRetries) {
//                System.out.println("🔁 Status is Started: will retry after another minute...");
//                updateOpsStatus(filePath, testcase, statusText);
//            } else {
//                System.out.println("⚠️ Status is still Started after retry or unknown status.");
//                updateOpsStatus(filePath, testcase, statusText);
//                return;
////                return; // Exit method if still not completed
//            }
//        }
//
//        captureScreenshot("Wave Status");
//          captureAllCardsScreenshots();
//        saveDocument(docPath);
////        Thread.sleep(3000);
////        GenerateTask();
//
//    }
//
//
//
//    public static void WaveSelectionAndRelatedlinks() throws InterruptedException, IOException {
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        //  js = (JavascriptExecutor) driver;
//        // wait = new WebDriverWait(driver, Duration.ofSeconds(5));
//        try {
//            WebElement cardView = wait.until(ExpectedConditions.elementToBeClickable(
//                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
//            ));
//            js.executeScript("arguments[0].scrollIntoView(true);", cardView);
//            cardView.click();
//            System.out.println("Card view selected.");
//        } catch (StaleElementReferenceException staleEx) {
//            System.out.println("Stale element detected. Retrying...");
//            WebElement cardViewRetry = wait.until(ExpectedConditions.elementToBeClickable(
//                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
//            ));
//
//            js.executeScript("arguments[0].scrollIntoView(true);", cardViewRetry);
//            cardViewRetry.click();
//            System.out.println("Card view selected after retry.");
//        } catch (Exception e) {
//            System.out.println("Failed to select the card view: " + e.getMessage());
//        }
//        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
//        By relatedLinksButtonLocator = By.cssSelector("button[data-component-id='relatedLinks']");
//        WebElement relatedLinksButton = waitShort.until(ExpectedConditions.elementToBeClickable(relatedLinksButtonLocator));
//        js = (JavascriptExecutor) driver;
//        js.executeScript("arguments[0].click();", relatedLinksButton);
//
//        System.out.println("Related Links button clicked.");
//
//    }
//    public static void Allocation() throws InterruptedException, IOException {
//        System.out.println("Allocation start");
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        By allocationsLocator = By.xpath("//ion-item[@data-component-id='Allocations']//a[text()='Allocations']");
//        WebElement allocationsLink = wait.until(ExpectedConditions.elementToBeClickable(allocationsLocator));
//        js = (JavascriptExecutor) driver;
//        js.executeScript("arguments[0].click();", allocationsLink);
//        System.out.println("Allocations clicked.");
//        Thread.sleep(5000);
//
//        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
//
//// Wait for the exact element to be visible
//        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
//        ));
//
//        System.out.println("✅ card-panel is visible. Proceeding with next actions...");
//        try {
//            Thread.sleep(8000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        captureScreenshot("Allocations");
//        captureAllCardsScreenshots();
//        saveDocument(docPath);
//    }
//    public static void navigateTillWaveRuns()  throws InterruptedException, IOException{
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        SearchMenu("Wave Run","OrderPlanningRunStrategy");
//        //
//
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//// Click on "Wave Runs" button
//        WebElement waveRunsButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("OrderPlanningRunStrategy")));
//        JavascriptExecutor js2 = (JavascriptExecutor) driver;
//        js2.executeScript("arguments[0].click();", waveRunsButton);
//        System.out.println("✅ Click on Wave Run");
//// Optional: wait for UI to update
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        try {
//            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//            WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("close-menu-button")));
//            closeButton.click();
//            System.out.println("✅ Close Button");
//        } catch (TimeoutException e) {
//            System.out.println("Close menu button not found or already closed.");
//        }
//
//
//
//
//
//
//
//
//
////        WebElement closeIcon = wait.until(ExpectedConditions.elementToBeClickable(By.id("close-menu-button")));
//////        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.id("close-menu-button")));
////        // Check if the icon is displayed (i.e., menu is open)
////        if (closeIcon.isDisplayed()) {
////             js = (JavascriptExecutor) driver;
////            js2.executeScript("arguments[0].click();", closeIcon);
////        } else {
////            System.out.println("Close icon is not visible. Menu might already be closed.");
////        }
//
//
////
//        //
//        // Wait for page to load
//
//        Thread.sleep(5000);
//        // Expand the item search section
//        WebElement filterBtnHost = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("(//ion-button[contains(@class,\"toggle-button\")])[3]")));
//        JavascriptExecutor jse = (JavascriptExecutor) driver;
//        // WebElement expandButton =(WebElement) jse.executeScript("return arguments[0].shadowRoot",filterBtnHost);
//        WebElement expandButton = (WebElement) jse.executeScript(
//                "let btn = arguments[0].shadowRoot.querySelector('.button-inner');" +
//                        " btn.click(); ",
//                filterBtnHost);
////
//        //
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        Thread.sleep(5000);
//// Wait until the button is clickable using its data-component-id
//        WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10));
//        WebElement expandButton1 = wait.until(
//                ExpectedConditions.elementToBeClickable(
//                        By.cssSelector("ion-button[data-component-id='OrderPlanningRunStrategy-Waverun-chevron-down']")
//                )
//        );
//
//// Scroll into view (optional)
//        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", expandButton1);
//        try {
//            Thread.sleep(3000); // Optional smooth scroll delay
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//// Use native click instead of JavaScript
//        expandButton1.click();
//        System.out.println("Wave Run chevron-down button clicked using native click.");
//
//
////
//        //
//        // Wait for the page to settle
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//
//
//        WebElement orderPlanningRunInputField = wait.until(
//                ExpectedConditions.elementToBeClickable(By.xpath("//ion-input[@data-component-id='OrderPlanningRunId-lookup-dialog-filter-input']//input"))
//        );
//
//
//// Define the value to enter
//
//
//// Enter the value
//        if (waveNumber != null && !waveNumber.isEmpty()) {
//            orderPlanningRunInputField.click();     // Focus the field
//            orderPlanningRunInputField.clear();     // Clear any existing value
//            orderPlanningRunInputField.sendKeys(waveNumber);// Type the value
//            orderPlanningRunInputField.sendKeys(Keys.ENTER);         // Optionally press Enter
//        }
//
//        System.out.println("Order Planning Run ID entered: " + waveNumber);
//
//
//    }
//
//    public static void navigateTillWaveRuns1()  throws InterruptedException, IOException {
//        //click on wave runs
//        WebElement waveRunsLink = driver.findElement(By.cssSelector("a[title='Wave Runs']"));
//        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", waveRunsLink);
//// Click the link
//        waveRunsLink.click();
//        Thread.sleep(5000);
//        System.out.println("Wave runs clicked.");
//
//    }
//    public static void GenerateTask() throws InterruptedException, IOException{
//        System.out.println("GenerateTask START");
//
//            Thread.sleep(3000);
//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//       JavascriptExecutor js = (JavascriptExecutor) driver;
//
//            Thread.sleep(12000);
//
//        System.out.println("Done");
//
//        System.out.println("Order Planning Run ID entered: " + waveNumber);
//
////
//        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("ion-backdrop")));
//        // cardselection
//        js = (JavascriptExecutor) driver;
//        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//        try {
//            WebElement cardView = wait.until(ExpectedConditions.elementToBeClickable(
//                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
//            ));
//            js.executeScript("arguments[0].scrollIntoView(true);", cardView);
//            cardView.click();
//            System.out.println("Card view selected.");
//        } catch (StaleElementReferenceException staleEx) {
//            System.out.println("Stale element detected. Retrying...");
//            WebElement cardViewRetry = wait.until(ExpectedConditions.elementToBeClickable(
//                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
//            ));
//
//            js.executeScript("arguments[0].scrollIntoView(true);", cardViewRetry);
//            cardViewRetry.click();
//            System.out.println("Card view selected after retry.");
//        } catch (Exception e) {
//            System.out.println("Failed to select the card view: " + e.getMessage());
//        }
//        wait = new WebDriverWait(driver, Duration.ofSeconds(25));
//
//// Wait for the parent container or trigger element to be visible first
//        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".footer-panel-more-label")));
//
//// Then try to locate and click the "More" button
//        WebElement moreButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-component-id='footer-panel-more-actions']")));
//        js.executeScript("arguments[0].scrollIntoView(true);", moreButton);
//        moreButton.click();
//
//// Check if it's enabled before clicking
//        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
//        WebElement generateTaskButton = wait.until(ExpectedConditions.elementToBeClickable(
//                By.cssSelector("button[data-component-id='footer-panel-more-actions-GenerateTask']")
//        ));
//        generateTaskButton.click();
//        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//
//// Wait for the popup's submit button to be visible and clickable
//        WebElement submitButton = wait.until(ExpectedConditions.elementToBeClickable(
//                By.cssSelector("ion-button[data-component-id='submit-btn']")
//        ));
//
//// Click the button
//        submitButton.click();
//        // related links
////        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
////        By relatedLinksButtonLocator = By.cssSelector("button[data-component-id='relatedLinks']");
////        WebElement relatedLinksButton = waitShort.until(ExpectedConditions.elementToBeClickable(relatedLinksButtonLocator));
////        js = (JavascriptExecutor) driver;
////        js.executeScript("arguments[0].click();", relatedLinksButton);
////        System.out.println("Related Links button clicked.");
//
//        System.out.println("Generate end");
//    }
//    public static void clickTasks() throws IOException, InterruptedException {
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
//        By allocationsLocator = By.xpath("//ion-item[@data-component-id='Tasks']//a[text()='Tasks']");
//        WebElement allocationsLink = waitShort.until(ExpectedConditions.elementToBeClickable(allocationsLocator));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("arguments[0].click();", allocationsLink);
//        System.out.println("Tasks clicked.");
////        captureScreenshot("Tasks");
////        saveDocument("TestScreenshots");
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
////        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
////        wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("background-content")));
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//
//// Wait for the exact element to be visible
//        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
//        ));
//        try {
//            Thread.sleep(10000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//
//        captureScreenshot("Tasks");
//        captureAllCardsScreenshots();
//        saveDocument(docPath);
//    }
//    public static void clickorders() throws InterruptedException, IOException {
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
//        By allocationsLocator = By.xpath("//ion-item[@data-component-id='Orders']//a[text()='Orders']");
//        WebElement allocationsLink = waitShort.until(ExpectedConditions.elementToBeClickable(allocationsLocator));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("arguments[0].click();", allocationsLink);
//        System.out.println("Orders clicked.");
//
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//
//// Wait for the exact element to be visible
//        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
//        ));
//        try {
//            Thread.sleep(10000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        captureScreenshot("Orders");
//        captureAllCardsScreenshots();
//        saveDocument(docPath);
//
//    }
//    public static void clickOLPNs() throws IOException, InterruptedException {
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
//        By oLPNsLocator = By.xpath("//ion-item[@data-component-id='oLPNs']//a[text()='oLPNs']");
//        WebElement oLPNsLink = waitShort.until(ExpectedConditions.elementToBeClickable(oLPNsLocator));
//        JavascriptExecutor js = (JavascriptExecutor) driver;
//        js.executeScript("arguments[0].click();", oLPNsLink);
//        System.out.println("oLPNs clicked.");
//        try {
//            Thread.sleep(3000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
//
//// Wait for the exact element to be visible
//        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
//                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
//        ));
//
//        try {
//            Thread.sleep(10000);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        captureScreenshot("Olpns");
//        captureAllCardsScreenshots();
//        saveDocument(docPath);
//
//
//
//
//
//    }
//    public static void DocumentName(String docName,String filePath) {
//
//        Random rand = new Random();
//        int randomNum = rand.nextInt(100000); // Generates a number between 0 and 99999
//        String uniqueDocName = docName + "_" + randomNum;
//        docPath = filePath + uniqueDocName + ".docx";
//        System.out.println(docPath);
//
//
//    }
//    public static void saveDocument(String docPath) {
//        try {
//
//            FileOutputStream out = new FileOutputStream(docPath);
//            document.write(out);
//            out.close();
//            // document.close(); // Uncomment if needed
//
//            System.out.println("Document saved at: " + docPath);
//        } catch (IOException e) {
//            System.out.println("Error saving document: " + e.getMessage());
//        }
//    }
//    public static void captureScreenshot(String fileName) {
//        try {
//            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
//            FileInputStream fis = new FileInputStream(srcFile);
//
//            XWPFParagraph paragraph = document.createParagraph();
//            XWPFRun run = paragraph.createRun();
//            run.setText("Screenshot: " + fileName);
//            run.addBreak();
//            run.addPicture(fis,
//                    Document.PICTURE_TYPE_PNG,
//                    fileName + ".png",
//                    Units.toEMU(500),
//                    Units.toEMU(300));
//
//            fis.close();
//
//            System.out.println("Screenshot added to document: " + fileName);
//        } catch (Exception e) {
//            System.out.println("Error capturing screenshot: " + e.getMessage());
//        }
//    }
//    public static void ReleaseTask()throws InterruptedException, IOException {
//
//
//
//
//        // WebDriverManager (if internet access is available)
//
//        Thread.sleep(5000);
//        // Locate the button using data-component-id attribute
//        WebElement selectAllButton = driver.findElement(By.cssSelector("button[data-component-id='selectAllRows']"));
//
//        // Click the button
//        selectAllButton.click();
//        try {
//            Thread.sleep(2000); // 20,000 milliseconds = 20 seconds
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
//        Thread.sleep(2000);
//        // Locate the ion-button using its unique data-component-id
//        WebElement releaseButton = wait.until(
//                ExpectedConditions.elementToBeClickable(
//                        By.cssSelector("ion-button[data-component-id='footer-panel-action-Release']")
//                )
//        );
//
//        // Click the button
//        releaseButton.click();
//        Thread.sleep(2000);
//        // Locate the button using data-component-id
//        WebElement yesButton = wait.until(
//                ExpectedConditions.elementToBeClickable(
//                        By.cssSelector("button[data-component-id='Yes']")
//                )
//        );
//
//        // Click the button
//        yesButton.click();
//
//
//    }
//
//    public static void updateOpsStatus(String filePath, String testcase, String waveStatus) {
//        closeExcelIfOpen();
//        String result = "Failed";
//        if (waveStatus != null && !waveStatus.isEmpty()) {
//            result = waveStatus;
//        }
//        try (FileInputStream fis = new FileInputStream(filePath);
//             Workbook workbook = new XSSFWorkbook(fis)) {
//            Sheet sheet = workbook.getSheet("OPS_Tab");
//            if (sheet == null) return;
//            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
//                Row row = sheet.getRow(i);
//                if (row == null) continue;
//                Cell tcCell = row.getCell(0);
//                if (tcCell == null) continue;
//                String tc = tcCell.getStringCellValue().trim();
//                if (tc.equalsIgnoreCase(testcase.trim())) {
//                    Cell resultCell = row.getCell(2);
//                    if (resultCell == null) resultCell = row.createCell(2);
//                    resultCell.setCellValue(result);
//                    break;
//                }
//            }
//            try (FileOutputStream fos = new FileOutputStream(filePath)) {
//                workbook.write(fos);
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//    private static void closeExcelIfOpen() {
//        try {
//            Process process = Runtime.getRuntime().exec("tasklist");
//            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
//            String line;
//            boolean excelRunning = false;
//            while ((line = reader.readLine()) != null) {
//                if (line.toLowerCase().contains("excel.exe")) {
//                    excelRunning = true;
//                    break;
//                }
//            }
//            if (excelRunning) {
//                System.out.println("⚠️ Excel is open. Closing it...");
//                Runtime.getRuntime().exec("taskkill /IM excel.exe /F");
//                Thread.sleep(2000);
//            }
//        } catch (Exception e) {
//            System.err.println("⚠️ Could not check/close Excel: " + e.getMessage());
//        }
//    }
//
//    public static void captureAllCardsScreenshots() throws InterruptedException, IOException {
//
//        List<WebElement> eles= driver.findElements(By.cssSelector("[role='main'] card-view"));
//        int i=1;
//        for(WebElement ele: eles){
//            //add scroll into view
//
//            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", ele);
//
//            captureScreenshot1(ele,i);
//            Thread.sleep(2000);
//            i++;
//        }
//
//
//    }
//    public static void captureScreenshot1(WebElement ele, int i) {
//        try {
//            File srcFile = ele.getScreenshotAs(OutputType.FILE);
//            FileInputStream fis = new FileInputStream(srcFile);
//
//            XWPFParagraph paragraph = document.createParagraph();
//            XWPFRun run = paragraph.createRun();
//            run.setText("Screenshot: " + i);
//            run.addBreak();
//            run.addPicture(fis, Document.PICTURE_TYPE_PNG, i + ".png", Units.toEMU(500), Units.toEMU(100));
//
//            fis.close();
//            System.out.println("Screenshot added: " + i);
//        } catch (Exception e) {
//            System.out.println("Error capturing screenshot: " + e.getMessage());
//        }
//    }
//
//
//}





















package MA_MSG_Suite_OB;
import com.google.gson.*;
import io.github.bonigarcia.wdm.WebDriverManager;
import okhttp3.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.util.Units;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.Document;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.*;
import java.nio.file.*;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.*;

import static javax.swing.UIManager.getString;

public class Main6a_WaveToReleaseTask {
    public static String statusText;
    // ❌ Removed static XWPFDocument to avoid carry-over across runs
    public static WebDriver driver;
    public static String waveNumber;
    // We’ll avoid using a static docPath and pass it around where needed
    public static Map<String, String> opsToWaveMap = new HashMap<>(); // OPS -> WaveNum
    public static Map<String, List<String>> waveTaskMap = new HashMap<>(); // Wave -> Task IDs
    public static Map<String, List<String>> waveOlpnMap = new HashMap<>(); // Wave -> OLPN IDs

    // =========================
    // MAIN (updated & complete)
    // =========================
    public static void main(String filePath, String testcase, String env) {
        // Fresh document per run
        XWPFDocument document = new XWPFDocument();
        String docPathLocal = null;

        // Reset static state that may leak across IDE runs
        waveNumber = null;
        opsToWaveMap.clear();
        waveTaskMap.clear();
        waveOlpnMap.clear();

        try {
            // Unique, timestamped output path (same directory as Excel)
            docPathLocal = buildDocPath(filePath, testcase);
            System.out.println("Output doc: " + docPathLocal);

            // Extract OPS
            String path = filePath;
            String testcaseToRun = testcase;
            String ops = getOpsForTestcase(path, testcaseToRun);
            System.out.println("Processing OPS: " + ops);

            // WebDriver & Login
            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--start-maximized");
            driver = new ChromeDriver(options);
            driver.manage().window().maximize();
            Main1_URL_Login1 login1 = new Main1_URL_Login1(driver, env);
            login1.execute();
            System.out.println("login done:\n");

            // Add a run header to the document
            addRunHeader(document, testcaseToRun, null);

            // Run OPS -> generate wave
            try {
                RunOPS(ops); // sets global waveNumber
                WavestatusWait(filePath, testcase, document, docPathLocal); // status + capture + save
            } catch (Exception e) {
                System.err.println("Error while processing OPS: " + ops);
                e.printStackTrace();
            }

            // Generate Task & downstream flow
            GenerateTask();
            System.out.println("Executing WaveToExcel after 20 sec");
            Thread.sleep(20000);
            Main6b_WaveToExcel.main(waveNumber, path, testcaseToRun);
            Thread.sleep(2000);

            WaveSelectionAndRelatedlinks();
            Thread.sleep(2000);
            Allocation(document, docPathLocal);
            Thread.sleep(2000);

            navigateTillWaveRuns1();
            Thread.sleep(2000);
            WaveSelectionAndRelatedlinks();
            Thread.sleep(2000);
            clickOLPNs(document, docPathLocal);
            Thread.sleep(2000);

            navigateTillWaveRuns1();
            Thread.sleep(2000);
            WaveSelectionAndRelatedlinks();
            Thread.sleep(2000);
            clickTasks(document, docPathLocal);
            Thread.sleep(2000);

            // Final single save for the run (safe even if intermediate saves happened)
            saveDocument(docPathLocal, document);

            if (driver != null) {
                driver.quit();
            }
            System.out.println(" Waving Done for Testcase"+testcase);
        } catch (Exception e) {
            System.err.println("❌ Error occurred: " + e.getMessage());
            e.printStackTrace();
            updateOpsStatus(filePath, testcase, "Failed");
            // Best-effort save on failure
            if (docPathLocal != null) {
                saveDocument(docPathLocal, document);
            }
        } finally {
            try {
                document.close();
            } catch (IOException ignore) {
            }
            if (driver != null) {
                try {
                    driver.quit();
                } catch (Exception ignore) {
                }
            }
        }
    }

    // =========================
    // Helpers (new/updated)
    // =========================

    // Build unique doc path (timestamped) in same dir as Excel
    public static String buildDocPath(String excelPathStr, String baseName) {
        Path excelPath = Paths.get(excelPathStr);
        Path parent = excelPath.getParent() != null ? excelPath.getParent() : Paths.get(".");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String unique = baseName + "_" + stamp + ".docx";
        return parent.resolve(unique).toString();
    }

    // Add a header for readability
    public static void addRunHeader(XWPFDocument document, String testcase, String waveNum) {
        XWPFParagraph p = document.createParagraph();
        XWPFRun r = p.createRun();
        r.setBold(true);
        r.setFontSize(12);
        r.setText("Run Summary | Testcase: " + (testcase != null ? testcase : "N/A")
                + " | Wave: " + (waveNum != null ? waveNum : "N/A"));
        r.addBreak();
    }

    public static void saveDocument(String docPath, XWPFDocument document) {
        try (FileOutputStream out = new FileOutputStream(docPath)) {
            document.write(out);
            System.out.println("Document saved at: " + docPath);
        } catch (IOException e) {
            System.out.println("Error saving document: " + e.getMessage());
        }
    }

    public static void captureScreenshot(String fileName, XWPFDocument document) {
        try {
            File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            try (FileInputStream fis = new FileInputStream(srcFile)) {
                XWPFParagraph paragraph = document.createParagraph();
                XWPFRun run = paragraph.createRun();
                run.setText("Screenshot: " + fileName);
                run.addBreak();
                run.addPicture(fis,
                        Document.PICTURE_TYPE_PNG,
                        fileName + ".png",
                        Units.toEMU(500),
                        Units.toEMU(300)); // taller height to avoid header-only capture
            }
            System.out.println("Screenshot added to document: " + fileName);
        } catch (Exception e) {
            System.out.println("Error capturing screenshot: " + e.getMessage());
        }
    }

    // Row-level capture to avoid repeating top-of-container visuals
    public static void captureAllCardsScreenshots(XWPFDocument document) throws InterruptedException, IOException {
        List<WebElement> rows = driver.findElements(
                By.cssSelector("[role='main'] card-view"));
                        //("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']"));
        int i = 1;
        for (WebElement row : rows) {
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block:'center'});", row);
            Thread.sleep(500);
            captureScreenshotRow(row, i, document);
            Thread.sleep(800);
            i++;
        }
    }

    public static void captureScreenshotRow(WebElement ele, int i, XWPFDocument document) {
        try {
            File srcFile = ele.getScreenshotAs(OutputType.FILE);
            try (FileInputStream fis = new FileInputStream(srcFile)) {
                XWPFParagraph paragraph = document.createParagraph();
                XWPFRun run = paragraph.createRun();
                run.setText("Card Row Screenshot: " + i);
                run.addBreak();
                run.addPicture(fis, Document.PICTURE_TYPE_PNG, i + ".png", Units.toEMU(500), Units.toEMU(100));
            }
            System.out.println("Row screenshot added: " + i);
        } catch (Exception e) {
            System.out.println("Error capturing row screenshot: " + e.getMessage());
        }
    }

    // =========================
    // Existing methods (adapted to pass document & docPath where needed)
    // =========================

    public static String getOpsForTestcase(String path, String testcaseToRun) throws IOException {
        try (FileInputStream fis = new FileInputStream(path);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheet("OPS_Tab");
            if (sheet == null) {
                System.out.println("❌ Sheet 'OPS & Wave Num' not found!");
                return null;
            }
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                String testcase = getCellValueAsString(row.getCell(0));
                if (testcase != null && testcase.trim().equalsIgnoreCase(testcaseToRun)) {
                    return getCellValueAsString(row.getCell(1)); // Column 1 = OPS
                }
            }
        }
        return null; // No matching testcase found
    }

    private static String getCellValueAsString(Cell cell) {
        if (cell == null) return "";
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            case NUMERIC:
                return String.valueOf((int) cell.getNumericCellValue()).trim();
            case BOOLEAN:
                return String.valueOf(cell.getBooleanCellValue()).trim();
            case FORMULA:
                return cell.getCellFormula().trim();
            default:
                return "";
        }
    }

    public static void fetchAndWriteTaskOlpnData(String token, String filePath) throws IOException {
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet taskSheet = workbook.getSheet("Tasks");
            if (taskSheet == null) {
                System.err.println("❌ Sheet 'Tasks' not found.");
                return;
            }
            Row row1 = taskSheet.getRow(1);
            if (row1 != null) {
                System.out.print("Row 1 values: ");
                for (int c = 0; c < row1.getLastCellNum(); c++) {
                    Cell cell = row1.getCell(c);
                    String value = (cell == null) ? "" : cell.toString();
                    System.out.print(value + " \n ");
                }
                System.out.println();
            }
            int taskRowIndex = 1;
            for (int i = 1; i <= taskSheet.getLastRowNum(); i++) {
                Row row = taskSheet.getRow(i);
                if (row == null) continue;
                Cell waveCell = row.getCell(0);
                if (waveCell == null) continue;
                String waveNumber = waveCell.getStringCellValue().trim();
                if (waveNumber.isEmpty()) continue;

                List<String> taskIds = fetchIds(waveNumber, "task", "GenerationNumberId", token, "com-manh-cp-task", "TaskId");
                List<String> olpnIds = fetchIds(waveNumber, "olpn", "OrderPlanningRunId", token, "com-manh-cp-pickpack", "OlpnId");

                System.out.println("Wave: " + waveNumber + " \n Tasks: " + taskIds + " \n OLPNs: " + olpnIds);
                waveTaskMap.put(waveNumber, taskIds);
                waveOlpnMap.put(waveNumber, olpnIds);

                String olpnId = olpnIds.isEmpty() ? "" : olpnIds.get(0);
                for (String taskId : taskIds) {
                    Row newRow = taskSheet.getRow(taskRowIndex);
                    if (newRow == null) {
                        newRow = taskSheet.createRow(taskRowIndex);
                    }
                    newRow.createCell(1).setCellValue(waveNumber); // Column B
                    newRow.createCell(2).setCellValue(taskId);     // Column C
                    newRow.createCell(8).setCellValue(olpnId);     // Column I
                    newRow.createCell(3).setCellValue("");         // Column D
                    taskRowIndex++;
                }
            }
            try (FileOutputStream fos = new FileOutputStream(filePath)) {
                workbook.write(fos);
            }
            System.out.println("✅ Task IDs and OLPN IDs written starting from row 2.");
        }
    }

    public static List<String> fetchIds(String waveNumber, String viewName, String attributeId, String token, String componentName, String idKey) {
        List<String> ids = new ArrayList<>();
        int maxRetries = 3;
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                OkHttpClient client = new OkHttpClient();
                MediaType mediaType = MediaType.parse("application/json");

                JsonObject filter = new JsonObject();
                filter.addProperty("ViewName", viewName);
                filter.addProperty("AttributeId", attributeId);
                filter.add("FilterValues", new Gson().toJsonTree(List.of(waveNumber.trim())));
                filter.addProperty("requiredFilter", false);
                filter.addProperty("Operator", "=");

                JsonObject body = new JsonObject();
                body.addProperty("ViewName", viewName.equalsIgnoreCase("olpn") ? "DMOlpn" : "Task");
                body.add("Filters", new Gson().toJsonTree(List.of(filter)));
                body.addProperty("ComponentName", componentName);
                body.addProperty("Size", 100);
                body.addProperty("TimeZone", "Europe/Paris");

                RequestBody requestBody = RequestBody.create(mediaType, body.toString());
                Request request = new Request.Builder()
                        .url("https://ujdss.sce.manh.com/dmui-facade/api/dmui-facade/entity/search")
                        .post(requestBody)
                        .addHeader("Content-Type", "application/json")
                        .addHeader("Authorization", "Bearer " + token)
                        .addHeader("SelectedOrganization", "HEERLEN51")
                        .addHeader("SelectedLocation", "HEERLEN51")
                        .build();

                Response response = client.newCall(request).execute();
                String responseBody = response.body() != null ? response.body().string() : "No response body";

                System.out.println("\n🔍 Attempt " + attempt + " for wave: " + waveNumber);
                System.out.println("Request Body: " + body.toString());
                System.out.println("Response Code: " + response.code());
                System.out.println("Response Body: " + responseBody);

                if (!response.isSuccessful()) {
                    System.err.println("❌ Failed to fetch " + idKey + " (HTTP " + response.code() + ")");
                    if (response.code() == 500 && attempt < maxRetries) {
                        System.out.println("🔁 Retrying...");
                        Thread.sleep(1000);
                        continue;
                    } else {
                        break;
                    }
                }

                JsonObject json = JsonParser.parseString(responseBody).getAsJsonObject();
                if (json.has("data")) {
                    JsonObject dataObject = json.getAsJsonObject("data");
                    if (dataObject.has("Results")) {
                        JsonArray results = dataObject.getAsJsonArray("Results");
                        for (JsonElement element : results) {
                            JsonObject obj = element.getAsJsonObject();
                            if (obj.has(idKey)) {
                                ids.add(obj.get(idKey).getAsString());
                            }
                        }
                    }
                }
                break;
            } catch (Exception e) {
                System.err.println("❌ Exception fetching " + idKey + " (Attempt " + attempt + "): " + e.getMessage());
            }
        }
        System.out.println("✅ Fetched " + ids.size() + " " + idKey + "(s) for wave: " + waveNumber);
        return ids;
    }

    public static void SearchMenu(String Keyword, String id) {
        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(15));
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;


            try {
                WebElement shadowHost = wait1.until(ExpectedConditions.presenceOfElementLocated(
                        By.cssSelector("ion-button[data-component-id='menu-toggle-button']")
                ));
                SearchContext shadowRoot = (SearchContext) js.executeScript("return arguments[0].shadowRoot", shadowHost);
                WebElement nativeButton = shadowRoot.findElement(By.cssSelector("button.button-native"));
                wait1.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("manh-overlay-container")));
                js.executeScript("arguments[0].click();", nativeButton);
                System.out.println("Menu toggle button clicked.");

            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
                e.printStackTrace(System.err);
            }


        try {
            WebElement innerInput = wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("ion-input[data-component-id='search-input'] input.native-input")
            ));
            wait.until(ExpectedConditions.elementToBeClickable(innerInput));
            innerInput.clear();
            innerInput.sendKeys(Keyword);
            System.out.println("✅ Search Done: " + Keyword);
        } catch (Exception e) {
            System.err.println("❌ Error interacting with search input: " + e.getMessage());
            e.printStackTrace();
        }

        try {
            WebElement element = wait.until(
                    ExpectedConditions.elementToBeClickable(By.id(id))
            );
            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].scrollIntoView({block: 'center'});", element
            );
            ((JavascriptExecutor) driver).executeScript(
                    "arguments[0].click();", element
            );
            System.out.println("Clicked element with id: " + id);
        } catch (Exception e) {
            System.err.println("Failed to click element with id: " + id);
            e.printStackTrace();
        }
    }

    public static void RunOPS(String OPS) throws InterruptedException, IOException {
        System.out.println("Run OPS starts");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        Thread.sleep(5000);
        System.out.println("OPS: " + OPS);
        SearchMenu("Order Planning Strategy", "orderPlanningStrategy");

        WebDriverWait wait1 = new WebDriverWait(driver, Duration.ofSeconds(10));
        System.out.println("closing Menu while RunOPS");
        WebElement closeIcon = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector("ion-icon[data-component-id='close']")
        ));
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", closeIcon);
        System.out.println("closing Menu while RunOPS Done");

        System.out.println("Order Planning Strategy button clicked.");

            Thread.sleep(5000);


        try {
            WebElement filterBtnHost = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//ion-button[contains(@class,\"toggle-button\")])[3]")
            ));
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            WebElement expandButton = (WebElement) jse.executeScript(
                    "let btn = arguments[0].shadowRoot.querySelector('.button-inner');" +
                            " btn.click(); ", filterBtnHost);

            System.out.println("Order Planning Strategy click on Filter button.");
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }

            Thread.sleep(5000);

        wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        List<WebElement> chevronUpButtons = driver.findElements(
                By.cssSelector("ion-button[data-component-id='OrderPlanningStrategy-Name-chevron-up']")
        );
        if (!chevronUpButtons.isEmpty()) {
            System.out.println("Chevron-up is already present. Skipping click.");
        } else {
            // Try to find the close-menu-button
            List<WebElement> closeButtons = driver.findElements(By.id("close-menu-button"));

            if (!closeButtons.isEmpty() && closeButtons.get(0).isDisplayed()) {
                // If present and visible, click it
                closeButtons.get(0).click();
            } else {

                try {
                // Otherwise, wait for expandButton1 and click it
                WebElement expandButton1 = wait.until(
                        ExpectedConditions.elementToBeClickable(
                                By.cssSelector("ion-button[data-component-id='OrderPlanningStrategy-Name-chevron-down']")
                        )
                );
                Thread.sleep(3000);
                expandButton1.click();
                System.out.println("Chevron-down button clicked using native click.");


            } catch (Exception e) {
                System.err.println("Error: " + e.getMessage());
                e.printStackTrace(System.err);
            }
        }
        }


        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }



        WebElement planningStrategyInputField = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath(
                        "//ion-input[@data-component-id='PlanningStrategyId']//input"
                ))
        );
        if (OPS != null && !OPS.isEmpty()) {
            planningStrategyInputField.click();
            planningStrategyInputField.sendKeys(Keys.CONTROL + "a");
            planningStrategyInputField.sendKeys(Keys.DELETE);
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            planningStrategyInputField.sendKeys(Keys.CONTROL + "a");
            planningStrategyInputField.sendKeys(Keys.DELETE);
            planningStrategyInputField.sendKeys(OPS);
            planningStrategyInputField.sendKeys(Keys.ENTER);
        }
        System.out.println("Planning Strategy ID entered: " + OPS);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement actionClosedButton = driver.findElement(
                By.cssSelector("button[data-component-id='action-closed']")
        );
        JavascriptExecutor js3 = (JavascriptExecutor) driver;
        js3.executeScript("arguments[0].scrollIntoView(true);", actionClosedButton);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        js3.executeScript("arguments[0].click();", actionClosedButton);
        System.out.println("Action Closed button clicked.");

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement runWaveButton = driver.findElement(
                By.cssSelector("button[data-component-id='RunWave']")
        );
        JavascriptExecutor js4 = (JavascriptExecutor) driver;
        js4.executeScript("arguments[0].scrollIntoView(true);", runWaveButton);
        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        js4.executeScript("arguments[0].click();", runWaveButton);
        System.out.println("Run Wave button clicked.");

        WebDriverWait wait5 = new WebDriverWait(driver, Duration.ofSeconds(5));
        WebElement toastMessage = wait5.until(ExpectedConditions.visibilityOfElementLocated(
                By.cssSelector(".toast-message .text-wrap")
        ));
        String popupText = toastMessage.getText();
        waveNumber = popupText.replaceAll(".*Wave\\s+(\\S+)\\s+is submitted.*", "$1");
        System.out.println("Wave Number: " + waveNumber);
        opsToWaveMap.put(OPS, waveNumber);
    }

    public static void WavestatusWait(String filePath, String testcase, XWPFDocument document, String docPathLocal)
            throws InterruptedException, IOException {
        System.out.println("WaveStatus starts");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;

        Thread.sleep(3000);
        SearchMenu("Wave Run", "OrderPlanningRunStrategy");


        Thread.sleep(5000);

        try {
            WebElement filterBtnHost = wait.until(ExpectedConditions.elementToBeClickable(
                    By.xpath("(//ion-button[contains(@class,\"toggle-button\")])[3]")
            ));
            JavascriptExecutor jse = (JavascriptExecutor) driver;
            WebElement expandButton = (WebElement) jse.executeScript(
                    "let btn = arguments[0].shadowRoot.querySelector('.button-inner');" +
                            " btn.click(); ", filterBtnHost);
            System.out.println("Clicked toggle button");

        }
        catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }


//
//        WebElement filterBtnHost = wait.until(ExpectedConditions.elementToBeClickable(
//                By.xpath("(//ion-button[contains(@class,\"toggle-button\")])[3]")
//        ));
//        JavascriptExecutor jse = (JavascriptExecutor) driver;
//        WebElement expandButton = (WebElement) jse.executeScript(
//                "let btn = arguments[0].shadowRoot.querySelector('.button-inner');" +
//                        " btn.click(); ", filterBtnHost);

        Thread.sleep(5000);

        try {
            WebElement expandButton1 = wait.until(
                    ExpectedConditions.elementToBeClickable(
                            By.cssSelector("ion-button[data-component-id='OrderPlanningRunStrategy-Waverun-chevron-down']")
                    )
            );
            ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", expandButton1);

            System.out.println("Wave Run chevron-down button clicked in 10 sec");

            Thread.sleep(5000);
            expandButton1.click();
            System.out.println("Wave Run chevron-down button clicked using native click.");

        }
        catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }


        Thread.sleep(3000);


        try{
            WebElement orderPlanningRunInputField = wait.until(
                    ExpectedConditions.elementToBeClickable(By.xpath("//ion-input[@data-component-id='OrderPlanningRunId-lookup-dialog-filter-input']//input"))
            );
            if (waveNumber != null && !waveNumber.isEmpty()) {
                orderPlanningRunInputField.click();
                orderPlanningRunInputField.clear();
                orderPlanningRunInputField.sendKeys(waveNumber);
                orderPlanningRunInputField.sendKeys(Keys.ENTER);
            }
            System.out.println("Order Planning Run ID entered: " + waveNumber);



        }
        catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }






        int maxRetries = 6;
        for (int attempt = 1; attempt <= maxRetries; attempt++) {
            System.out.println("⏳ Waiting 30 seconds before refreshing...");
            try {
                Thread.sleep(30000);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            WebElement refreshHost = driver.findElement(By.cssSelector("ion-button.refresh-button"));
            js = (JavascriptExecutor) driver;
            WebElement refreshButton = (WebElement) js.executeScript(
                    "return arguments[0].shadowRoot.querySelector('button.button-native')", refreshHost);
            refreshButton.click();
            System.out.println("🔄 Refresh button clicked.");

            Thread.sleep(3000);

            WebElement statusElement = wait.until(ExpectedConditions.visibilityOfElementLocated(
                    By.cssSelector("div[data-component-id='PlanningStatusDescription']")
            ));
            statusText = statusElement.getText().trim();
            System.out.println("📌 Planning Status: " + statusText);

            if ("Completed".equalsIgnoreCase(statusText)) {
                System.out.println("✅ Status is Completed: OK " + statusText);
                updateOpsStatus(filePath, testcase, statusText);
                break;
            } else if ("Cancelled".equalsIgnoreCase(statusText)) {
                System.out.println("❌ Status is Cancelled: skipping further actions.");
                updateOpsStatus(filePath, testcase, statusText);
                Thread.sleep(3000);
                captureScreenshot("Wave Status", document);
                captureAllCardsScreenshots(document);
                saveDocument(docPathLocal, document);
                return;
            } else if ("Started".equalsIgnoreCase(statusText) && attempt < maxRetries) {
                System.out.println("🔁 Status is Started: will retry after another minute...");
                updateOpsStatus(filePath, testcase, statusText);
            } else {
                System.out.println("⚠️ Status is still Started after retry or unknown status.");
                updateOpsStatus(filePath, testcase, statusText);
                return;
            }
        }
        Thread.sleep(3000);
        captureScreenshot("Wave Status", document);
        captureAllCardsScreenshots(document);
        saveDocument(docPathLocal, document);
    }

    public static void WaveSelectionAndRelatedlinks() throws InterruptedException, IOException {
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        try {
            WebElement cardView = wait.until(ExpectedConditions.elementToBeClickable(
                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
            ));
            js.executeScript("arguments[0].scrollIntoView(true);", cardView);
            cardView.click();
            System.out.println("Card view selected.");
        } catch (StaleElementReferenceException staleEx) {
            System.out.println("Stale element detected. Retrying...");
            WebElement cardViewRetry = wait.until(ExpectedConditions.elementToBeClickable(
                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
            ));
            js.executeScript("arguments[0].scrollIntoView(true);", cardViewRetry);
            cardViewRetry.click();
            System.out.println("Card view selected after retry.");
        } catch (Exception e) {
            System.out.println("Failed to select the card view: " + e.getMessage());
        }

        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
        By relatedLinksButtonLocator = By.cssSelector("button[data-component-id='relatedLinks']");
        WebElement relatedLinksButton = waitShort.until(ExpectedConditions.elementToBeClickable(relatedLinksButtonLocator));
        js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", relatedLinksButton);
        System.out.println("Related Links button clicked.");
    }

    public static void Allocation(XWPFDocument document, String docPathLocal) throws InterruptedException, IOException {
        System.out.println("Allocation start");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        By allocationsLocator = By.xpath("//ion-item[@data-component-id='Allocations']//a[text()='Allocations']");
        WebElement allocationsLink = wait.until(ExpectedConditions.elementToBeClickable(allocationsLocator));
        js.executeScript("arguments[0].click();", allocationsLink);
        System.out.println("Allocations clicked.");
        Thread.sleep(5000);

        wait = new WebDriverWait(driver, Duration.ofSeconds(20));
        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
        ));
        System.out.println("✅ card-panel is visible. Proceeding with next actions...");
        try {
            Thread.sleep(8000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        captureScreenshot("Allocations", document);
        captureAllCardsScreenshots(document);
        saveDocument(docPathLocal, document);
    }

    public static void navigateTillWaveRuns() throws InterruptedException, IOException {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        SearchMenu("Wave Run", "OrderPlanningRunStrategy");

        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        WebElement waveRunsButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("OrderPlanningRunStrategy")));
        JavascriptExecutor js2 = (JavascriptExecutor) driver;
        js2.executeScript("arguments[0].click();", waveRunsButton);
        System.out.println("✅ Click on Wave Run");

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        try {
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            WebElement closeButton = wait.until(ExpectedConditions.elementToBeClickable(By.id("close-menu-button")));
            closeButton.click();
            System.out.println("✅ Close Button");
        } catch (TimeoutException e) {
            System.out.println("Close menu button not found or already closed.");
        }

        Thread.sleep(5000);

        WebElement filterBtnHost = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("(//ion-button[contains(@class,\"toggle-button\")])[3]")
        ));
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        WebElement expandButton = (WebElement) jse.executeScript(
                "let btn = arguments[0].shadowRoot.querySelector('.button-inner');" +
                        " btn.click(); ", filterBtnHost);

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Thread.sleep(5000);

        WebDriverWait wait3 = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement expandButton1 = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.cssSelector("ion-button[data-component-id='OrderPlanningRunStrategy-Waverun-chevron-down']")
                )
        );
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", expandButton1);
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        expandButton1.click();
        System.out.println("Wave Run chevron-down button clicked using native click.");

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebElement orderPlanningRunInputField = wait.until(
                ExpectedConditions.elementToBeClickable(By.xpath("//ion-input[@data-component-id='OrderPlanningRunId-lookup-dialog-filter-input']//input"))
        );
        if (waveNumber != null && !waveNumber.isEmpty()) {
            orderPlanningRunInputField.click();
            orderPlanningRunInputField.clear();
            orderPlanningRunInputField.sendKeys(waveNumber);
            orderPlanningRunInputField.sendKeys(Keys.ENTER);
        }
        System.out.println("Order Planning Run ID entered: " + waveNumber);
    }

    public static void navigateTillWaveRuns1() throws InterruptedException, IOException {
        WebElement waveRunsLink = driver.findElement(By.cssSelector("a[title='Wave Runs']"));
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", waveRunsLink);
        waveRunsLink.click();
        Thread.sleep(5000);
        System.out.println("Wave runs clicked.");
    }

    public static void GenerateTask() throws InterruptedException, IOException {
        System.out.println("GenerateTask START");
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        Thread.sleep(12000);
        System.out.println("Order Planning Run ID entered: " + waveNumber);

        wait.until(ExpectedConditions.invisibilityOfElementLocated(By.cssSelector("ion-backdrop")));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        System.out.println("Done1");
        wait = new WebDriverWait(driver, Duration.ofSeconds(5));
        try {
            WebElement cardView = wait.until(ExpectedConditions.elementToBeClickable(
                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
            ));
            js.executeScript("arguments[0].scrollIntoView(true);", cardView);
            cardView.click();
            System.out.println("Card view selected.");
        } catch (StaleElementReferenceException staleEx) {
            System.out.println("Stale element detected. Retrying...");
            WebElement cardViewRetry = wait.until(ExpectedConditions.elementToBeClickable(
                    By.cssSelector("card-view[data-component-id='Card-View'] .card-row.primary[tabindex='0']")
            ));
            js.executeScript("arguments[0].scrollIntoView(true);", cardViewRetry);
            cardViewRetry.click();
            System.out.println("Card view selected after retry.");
        } catch (Exception e) {
            System.out.println("Failed to select the card view: " + e.getMessage());
        }

        System.out.println("Searching Presence of footer-panel-more-label");

        wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.cssSelector(".footer-panel-more-label")));
        WebElement moreButton = wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[data-component-id='footer-panel-more-actions']")));
        moreButton.click();

        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement generateTaskButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("button[data-component-id='footer-panel-more-actions-GenerateTask']")
        ));
        generateTaskButton.click();

        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        WebElement submitButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.cssSelector("ion-button[data-component-id='submit-btn']")
        ));
        submitButton.click();

        System.out.println("Generate end");
    }

    public static void clickTasks(XWPFDocument document, String docPathLocal) throws IOException, InterruptedException {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
        By allocationsLocator = By.xpath("//ion-item[@data-component-id='Tasks']//a[text()='Tasks']");
        WebElement allocationsLink = waitShort.until(ExpectedConditions.elementToBeClickable(allocationsLocator));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", allocationsLink);
        System.out.println("Tasks clicked.");

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
        ));
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        captureScreenshot("Tasks", document);
        captureAllCardsScreenshots(document);
        saveDocument(docPathLocal, document);
    }

    public static void clickorders(XWPFDocument document, String docPathLocal) throws InterruptedException, IOException {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
        By allocationsLocator = By.xpath("//ion-item[@data-component-id='Orders']//a[text()='Orders']");
        WebElement allocationsLink = waitShort.until(ExpectedConditions.elementToBeClickable(allocationsLocator));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", allocationsLink);
        System.out.println("Orders clicked.");

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
        ));
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        captureScreenshot("Orders", document);
        captureAllCardsScreenshots(document);
        saveDocument(docPathLocal, document);
    }

    public static void clickOLPNs(XWPFDocument document, String docPathLocal) throws IOException, InterruptedException {
        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        WebDriverWait waitShort = new WebDriverWait(driver, Duration.ofSeconds(5));
        By oLPNsLocator = By.xpath("//ion-item[@data-component-id='oLPNs']//a[text()='oLPNs']");
        WebElement oLPNsLink = waitShort.until(ExpectedConditions.elementToBeClickable(oLPNsLocator));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", oLPNsLink);
        System.out.println("oLPNs clicked.");

        try {
            Thread.sleep(3000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(30));
        WebElement cardPanel = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("/html/body/app-root/ion-app/div/ion-split-pane/ion-router-outlet/screen-page/div/div/div[2]/div/ion-content/card-panel")
        ));
        try {
            Thread.sleep(10000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        captureScreenshot("Olpns", document);
        captureAllCardsScreenshots(document);
        saveDocument(docPathLocal, document);
    }

    // (Old DocumentName kept for compatibility but unused)
    public static void DocumentName(String docName, String filePath) {
        // Deprecated in favor of buildDocPath
        Random rand = new Random();
        int randomNum = rand.nextInt(100000);
        String uniqueDocName = docName + "_" + randomNum;
        String docPath = filePath + uniqueDocName + ".docx";
        System.out.println(docPath);
    }

    public static void ReleaseTask() throws InterruptedException, IOException {
        Thread.sleep(5000);
        WebElement selectAllButton = driver.findElement(By.cssSelector("button[data-component-id='selectAllRows']"));
        selectAllButton.click();
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        Thread.sleep(2000);

        WebElement releaseButton = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.cssSelector("ion-button[data-component-id='footer-panel-action-Release']")
                )
        );
        releaseButton.click();
        Thread.sleep(2000);

        WebElement yesButton = wait.until(
                ExpectedConditions.elementToBeClickable(
                        By.cssSelector("button[data-component-id='Yes']")
                )
        );
        yesButton.click();
    }

    public static void updateOpsStatus(String filePath, String testcase, String waveStatus) {
        closeExcelIfOpen();
        String result = "Failed";
        if (waveStatus != null && !waveStatus.isEmpty()) {
            result = waveStatus;
        }
        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {
            Sheet sheet = workbook.getSheet("OPS_Tab");
            if (sheet == null) return;
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                if (row == null) continue;
                Cell tcCell = row.getCell(0);
                if (tcCell == null) continue;
                String tc = tcCell.getStringCellValue().trim();
                if (tc.equalsIgnoreCase(testcase.trim())) {
                    Cell resultCell = row.getCell(2);
                    if (resultCell == null) resultCell = row.createCell(2);
                    resultCell.setCellValue(result);
                    break;
                }
            }
            try (FileOutputStream fos = new FileOutputStream(filePath)) {
                workbook.write(fos);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void closeExcelIfOpen() {
        try {
            Process process = Runtime.getRuntime().exec("tasklist");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String line;
            boolean excelRunning = false;
            while ((line = reader.readLine()) != null) {
                if (line.toLowerCase().contains("excel.exe")) {
                    excelRunning = true;
                    break;
                }
            }
            if (excelRunning) {
                System.out.println("⚠️ Excel is open. Closing it...");
                Runtime.getRuntime().exec("taskkill /IM excel.exe /F");
                Thread.sleep(2000);
            }
        } catch (Exception e) {
            System.err.println("⚠️ Could not check/close Excel: " + e.getMessage());
        }
    }
}