package com.example.msgrunner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsgRunnerApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsgRunnerApplication.class, args);
    }
}
